package com.nilkamal.orders

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import java.util.Locale

val Rose = Color(0xFFBE123C)
val Ink = Color(0xFF0F172A)

fun rs(n: Long): String = "₹" + String.format(Locale.US, "%,d", n)

fun pname(p: Product, lang: String): String =
    when (lang) { "hi" -> p.nameHi; "mr" -> p.nameMr; else -> p.name }.ifBlank { p.name }

// Photo, or a flower when there is no picture
@Composable
fun Photo(url: String, modifier: Modifier, size: Int = 32) {
    if (url.isNotEmpty()) {
        AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = modifier)
    } else {
        Box(modifier.background(Color(0xFFFFE4E6)), contentAlignment = Alignment.Center) {
            Text("🌸", fontSize = size.sp)
        }
    }
}

@Composable
fun Pill(text: String, bg: Color? = null, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .background(bg ?: Color.White.copy(alpha = 0.92f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (bg != null) Color.White else Color.Black, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Chip(text: String, on: Boolean, onClick: () -> Unit) {
    if (on) Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text(text) }
    else OutlinedButton(onClick = onClick) { Text(text) }
}

// Full-screen photo: pinch or double-tap to zoom, drag to look around
@Composable
fun PhotoViewer(url: String, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            var scale by remember { mutableStateOf(1f) }
            var offset by remember { mutableStateOf(Offset.Zero) }
            AsyncImage(
                model = url, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(onDoubleTap = {
                            scale = if (scale > 1f) 1f else 2.5f
                            offset = Offset.Zero
                        })
                    }
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offset = if (scale <= 1f) Offset.Zero else offset + pan
                        }
                    }
                    .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
            )
            Button(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(12.dp)) { Text("✕") }
            Text(
                t("tapZoom"), color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp,
                modifier = Modifier.align(Alignment.BottomCenter).systemBarsPadding().padding(12.dp)
            )
        }
    }
}

data class DetailData(
    val name: String, val nameHi: String, val nameMr: String, val category: String,
    val price: Long, val defPrice: Long?, val imageUrl: String
)

// Amazon-style product page: photo on top, details below, tap the photo to open it
@Composable
fun DetailDialog(d: DetailData, onClose: () -> Unit, actions: @Composable ColumnScope.() -> Unit) {
    var viewer by remember { mutableStateOf(false) }
    val lang = LocalLang.current
    val title = when (lang) { "hi" -> d.nameHi; "mr" -> d.nameMr; else -> d.name }.ifBlank { d.name }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState())) {
                OutlinedButton(onClick = onClose, modifier = Modifier.padding(8.dp)) { Text("← " + t("closeBtn")) }
                Photo(
                    d.imageUrl,
                    Modifier.fillMaxWidth().aspectRatio(1f).clickable(enabled = d.imageUrl.isNotEmpty()) { viewer = true },
                    64
                )
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    if (d.category.isNotEmpty()) Text(t(d.category))
                    Text(rs(d.price), color = Rose, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    val dp0 = d.defPrice
                    if (dp0 != null && dp0 != d.price) {
                        Text(t("listPrice") + ": " + rs(dp0), textDecoration = TextDecoration.LineThrough)
                    }
                    actions()
                }
            }
        }
    }
    if (viewer) PhotoViewer(d.imageUrl) { viewer = false }
}

fun pickDateTime(ctx: android.content.Context, onPicked: (Long) -> Unit) {
    val c = java.util.Calendar.getInstance()
    android.app.DatePickerDialog(ctx, { _, y, m, d ->
        android.app.TimePickerDialog(ctx, { _, h, min ->
            val cal = java.util.Calendar.getInstance()
            cal.set(y, m, d, h, min, 0)
            cal.set(java.util.Calendar.MILLISECOND, 0)
            onPicked(cal.timeInMillis)
        }, c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), false).show()
    }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show()
}
