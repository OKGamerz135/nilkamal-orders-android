package com.nilkamal.orders

// TEMPORARY TEST - remove after the auth_time check. Admin only (Account tab).
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

private suspend fun check(label: String, block: suspend () -> String): String =
    try {
        label + ": " + block()
    } catch (e: FirebaseFirestoreException) {
        label + ": ❌ " + e.code.name
    } catch (e: Exception) {
        label + ": ❌ " + (e.message ?: e.javaClass.simpleName)
    }

private suspend fun runProbe(): String {
    val lines = mutableListOf<String>()
    val user = FirebaseAuth.getInstance().currentUser ?: return "Not signed in"
    val db = FirebaseFirestore.getInstance()
    val t1 = withTimeoutOrNull(20_000L) { user.getIdToken(false).await2() } ?: return "Could not get the token (offline?)"
    lines += "Claims in the token: " + t1.claims.keys.sorted().joinToString(", ")
    lines += "auth_time (SDK): " + t1.authTimestamp
    lines += "auth_time (claim): " + t1.claims["auth_time"] + " [" + (t1.claims["auth_time"]?.javaClass?.simpleName ?: "missing") + "]"
    lines += "iat: " + t1.issuedAtTimestamp
    lines += ""
    lines += "TEST A - can the rules see auth_time?"
    for (id in listOf("exists", "is_int", "is_number", "is_timestamp")) {
        lines += check("  " + id) { db.collection("zz_probe").document(id).get(Source.SERVER).await2(); "✅ rule passed" }
    }
    val docId = user.uid + "_" + t1.authTimestamp
    lines += ""
    lines += "TEST B - can the rules rebuild the same ID the app builds? (…" + docId.takeLast(12) + ")"
    lines += check("  write pointer") {
        db.collection("zz_probe_b").document(docId).set(hashMapOf("uid" to user.uid, "at" to FieldValue.serverTimestamp())).await2()
        "✅ allowed"
    }
    lines += check("  read (rules look up the rebuilt ID)") {
        val s = db.collection("zz_probe_b").document(docId).get(Source.SERVER).await2()
        if (s.exists()) "✅ passed" else "⚠ passed, but document missing"
    }
    lines += ""
    lines += "TEST C - does auth_time survive a token refresh?"
    val t2 = withTimeoutOrNull(20_000L) { user.getIdToken(true).await2() }
    if (t2 == null) {
        lines += "  could not refresh the token"
    } else {
        lines += "  auth_time before / after: " + t1.authTimestamp + " / " + t2.authTimestamp +
            (if (t1.authTimestamp == t2.authTimestamp) "  ✅ unchanged" else "  ❌ CHANGED")
        lines += "  iat before / after: " + t1.issuedAtTimestamp + " / " + t2.issuedAtTimestamp
        lines += check("  read again with the new token") {
            val s = db.collection("zz_probe_b").document(docId).get(Source.SERVER).await2()
            if (s.exists()) "✅ passed" else "⚠ passed, but document missing"
        }
    }
    return lines.joinToString("\n")
}

@Composable
fun AuthTimeProbeCard() {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var out by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxWidth().border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(12.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("🧪 auth_time test (temporary)", fontWeight = FontWeight.Bold)
        Button(onClick = { scope.launch { busy = true; out = runProbe(); busy = false } }, enabled = !busy) {
            Text(if (busy) "Running…" else "Run test")
        }
        if (out.isNotEmpty()) Text(out, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    }
}
