package com.nilkamal.orders

import android.app.TimePickerDialog
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HoursDoc(val startMin: Int, val endMin: Int, val lateUntil: Long)

data class DeviceRow(
    val id: String, val email: String, val name: String, val os: String, val app: String,
    val platform: String, val lastSeen: Date?, val lastLogin: Date?
)

@Composable
fun rememberHoursDoc(): HoursDoc {
    var h by remember { mutableStateOf(HoursDoc(420, 1290, 0L)) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("settings").document("hours").addSnapshotListener { s, _ ->
            if (s != null && s.exists()) {
                h = HoursDoc(
                    s.getLong("startMin")?.toInt() ?: 420, s.getLong("endMin")?.toInt() ?: 1290,
                    s.getTimestamp("lateUntil")?.toDate()?.time ?: 0L
                )
            }
        }
        onDispose { reg.remove() }
    }
    return h
}

@Composable
fun rememberDeviceRows(): List<DeviceRow> {
    var list by remember { mutableStateOf(emptyList<DeviceRow>()) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("devices")
            .orderBy("lastSeen", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, _ ->
                if (snap != null) list = snap.documents.map { d ->
                    DeviceRow(
                        d.id, d.getString("email") ?: "", d.getString("deviceName") ?: "", d.getString("osVersion") ?: "",
                        d.getString("appVersion") ?: "", d.getString("platform") ?: "",
                        d.getTimestamp("lastSeen")?.toDate(), d.getTimestamp("lastLoginAt")?.toDate()
                    )
                }
            }
        onDispose { reg.remove() }
    }
    return list
}

fun fmtMinutes(min: Int): String {
    val h = min / 60
    val h12 = if (h % 12 == 0) 12 else h % 12
    return h12.toString() + ":" + (if (min % 60 < 10) "0" else "") + (min % 60) + (if (h < 12) " AM" else " PM")
}

// Writes the working hours / late shift. Always writes both times so the server rules can read them.
fun saveHours(start: Int, end: Int, lateUntilMs: Long?, clearLate: Boolean) {
    val email = FirebaseAuth.getInstance().currentUser?.email ?: ""
    val data = hashMapOf<String, Any>(
        "startMin" to start.toLong(), "endMin" to end.toLong(),
        "updatedBy" to email, "updatedAt" to FieldValue.serverTimestamp()
    )
    if (lateUntilMs != null) data["lateUntil"] = Timestamp(Date(lateUntilMs))
    else if (clearLate) data["lateUntil"] = FieldValue.delete()
    FirebaseFirestore.getInstance().collection("settings").document("hours").set(data, SetOptions.merge())
}

private fun pickTime(ctx: Context, initial: Int, onPicked: (Int) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> onPicked(h * 60 + m) }, initial / 60, initial % 60, false).show()
}

// Admin only: employees' working hours, late shift, and the list of devices that signed in
@Composable
fun SecurityScreen() {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val hd = rememberHoursDoc()
    val devices = rememberDeviceRows()
    val fmt = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }
    fun fd(d: Date?): String = if (d == null) "…" else fmt.format(d)
    val trusted = Lease.trustedNowMs(ctx)
    val lateOn = hd.lateUntil > trusted
    val shape = RoundedCornerShape(12.dp)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Column(
                Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.dp, Color(0xFFE2E8F0), shape).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("⏰ " + t("workingHours"), fontWeight = FontWeight.Bold)
                Text(fmtMinutes(hd.startMin) + " – " + fmtMinutes(hd.endMin), fontSize = 20.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        pickTime(ctx, hd.startMin) { m ->
                            if (m >= hd.endMin) Toast.makeText(ctx, tr(lang, "badHours"), Toast.LENGTH_SHORT).show()
                            else {
                                saveHours(m, hd.endMin, null, false)
                                AuditLog.add("settings.hours", "hours", fmtMinutes(m) + " – " + fmtMinutes(hd.endMin))
                            }
                        }
                    }, modifier = Modifier.weight(1f)) { Text(t("fromTime") + " " + fmtMinutes(hd.startMin)) }
                    OutlinedButton(onClick = {
                        pickTime(ctx, hd.endMin) { m ->
                            if (m <= hd.startMin) Toast.makeText(ctx, tr(lang, "badHours"), Toast.LENGTH_SHORT).show()
                            else {
                                saveHours(hd.startMin, m, null, false)
                                AuditLog.add("settings.hours", "hours", fmtMinutes(hd.startMin) + " – " + fmtMinutes(m))
                            }
                        }
                    }, modifier = Modifier.weight(1f)) { Text(t("toTime") + " " + fmtMinutes(hd.endMin)) }
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().clip(shape).background(if (lateOn) Color(0xFFFEF3C7) else Color.White)
                    .border(1.dp, Color(0xFFE2E8F0), shape).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("🌙 " + t("lateShift"), fontWeight = FontWeight.Bold)
                Text(
                    if (lateOn) t("lateOnUntil") + " " + fmt.format(Date(hd.lateUntil)) else t("lateOff"),
                    fontWeight = if (lateOn) FontWeight.Bold else FontWeight.Normal
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(2, 4, 8).forEach { hrs ->
                        Button(onClick = {
                            saveHours(hd.startMin, hd.endMin, Lease.trustedNowMs(ctx) + hrs * 3_600_000L, false)
                            AuditLog.add("settings.late_on", "hours", hrs.toString() + "h")
                        }, modifier = Modifier.weight(1f)) { Text(hrs.toString() + "h") }
                    }
                }
                if (lateOn) {
                    OutlinedButton(onClick = {
                        saveHours(hd.startMin, hd.endMin, Lease.trustedNowMs(ctx), false)
                        AuditLog.add("settings.late_off", "hours", "")
                    }, modifier = Modifier.fillMaxWidth()) { Text(t("stopLate")) }
                }
            }
        }
        item { Text("📱 " + t("devices"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (devices.isEmpty()) item { Text(t("noDevices")) }
        items(devices, key = { it.id }) { d ->
            val active = d.lastSeen != null && System.currentTimeMillis() - d.lastSeen.time < 15 * 60_000L
            Column(
                Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.dp, Color(0xFFE2E8F0), shape).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text((if (active) "🟢 " else "⚪ ") + d.email, fontWeight = FontWeight.Bold)
                val os = if (d.platform == "web") "web" else "Android " + d.os
                Text(d.name + " · " + os + " · v" + d.app, fontSize = 13.sp)
                Text(t("lastLogin") + ": " + fd(d.lastLogin), fontSize = 13.sp, color = Color(0xFF475569))
                Text(t("lastSeen") + ": " + fd(d.lastSeen), fontSize = 13.sp, color = Color(0xFF475569))
            }
        }
    }
}
