package com.nilkamal.orders

import android.content.Context
import android.os.Build
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import java.util.UUID

// A random ID for this installation + the phone's model, so the admin can see who signed in where
object Device {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("device", Context.MODE_PRIVATE)

    fun id(ctx: Context): String {
        val p = prefs(ctx)
        val old = p.getString("id", null)
        if (old != null) return old
        val fresh = UUID.randomUUID().toString().replace("-", "")
        p.edit().putString("id", fresh).apply()
        return fresh
    }

    fun docId(ctx: Context, uid: String): String = id(ctx) + "_" + uid
    fun name(): String = (Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL).trim()
    fun label(): String = name() + " · Android " + Build.VERSION.RELEASE + " · v" + BuildConfig.VERSION_NAME
    fun markLogin(ctx: Context) { prefs(ctx).edit().putBoolean("justLoggedIn", true).apply() }

    fun info(ctx: Context, user: FirebaseUser): HashMap<String, Any> {
        val m = hashMapOf<String, Any>(
            "uid" to user.uid, "email" to (user.email ?: ""), "deviceId" to id(ctx), "deviceName" to name(),
            "platform" to "android", "osVersion" to Build.VERSION.RELEASE, "appVersion" to BuildConfig.VERSION_NAME,
            "lastSeen" to FieldValue.serverTimestamp()
        )
        val p = prefs(ctx)
        if (p.getBoolean("justLoggedIn", false)) {
            m["lastLoginAt"] = FieldValue.serverTimestamp()
            p.edit().putBoolean("justLoggedIn", false).apply()
        }
        return m
    }
}
