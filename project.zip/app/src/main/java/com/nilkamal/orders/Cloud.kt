package com.nilkamal.orders

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

// Shrinks a photo (max 900px) and uploads it to Cloudinary, returns the picture's web address
object Cloud {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun compress(ctx: Context, uri: Uri): ByteArray {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1800) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("Could not read the photo")
        val orientation = ctx.contentResolver.openInputStream(uri).use { s ->
            if (s == null) ExifInterface.ORIENTATION_NORMAL
            else ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val k = minOf(1f, 900f / maxOf(bmp.width, bmp.height))
        val m = Matrix()
        m.postScale(k, k)
        m.postRotate(degrees)
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        val bytes = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 80, bytes)
        return bytes.toByteArray()
    }

    fun upload(ctx: Context, uri: Uri): String {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("upload_preset", BuildConfig.UPLOAD_PRESET)
            .addFormDataPart("file", "photo.jpg", compress(ctx, uri).toRequestBody("image/jpeg".toMediaType()))
            .build()
        val req = Request.Builder()
            .url("https://api.cloudinary.com/v1_1/" + BuildConfig.CLOUD_NAME + "/image/upload")
            .post(body).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("Upload failed " + r.code)
            val text = r.body?.string() ?: throw IOException("Empty answer")
            return JSONObject(text).getString("secure_url")
        }
    }
}
