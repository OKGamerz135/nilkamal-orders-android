package com.nilkamal.orders

import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : FragmentActivity() {
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Rose)) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        // coming back after more than a minute: ask for fingerprint / PIN again (admin and family)
        if (stoppedAt > 0 && SystemClock.elapsedRealtime() - stoppedAt > 60_000L) LockState.needUnlock = true
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    val auth = remember { FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var lang by remember { mutableStateOf(prefs.getString("lang", "en") ?: "en") }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener {
            user = it.currentUser
            if (it.currentUser == null) Lease.clear(ctx) // a new person signing in starts with a fresh lease
        }
        auth.addAuthStateListener(l)
        onDispose { auth.removeAuthStateListener(l) }
    }
    CompositionLocalProvider(LocalLang provides lang) {
        val u = user
        if (u == null) {
            Box(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) { Login(auth) }
        } else if (LockState.needUnlock && AppLock.applies(ctx)) {
            UnlockScreen()
        } else {
            Main(auth, u.uid, u.email ?: "", lang) { l ->
                lang = l
                prefs.edit().putString("lang", l).apply()
            }
        }
    }
}

@Composable
fun UnlockScreen() {
    val ctx = LocalContext.current
    val activity = ctx.findFragmentActivity()
    val title = t("unlock")
    fun go() {
        if (activity != null) AppLock.prompt(activity, title) { LockState.needUnlock = false }
        else LockState.needUnlock = false
    }
    LaunchedEffect(Unit) { go() }
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔒", fontSize = 56.sp)
        Text(t("lockedTitle"), style = MaterialTheme.typography.headlineMedium)
        Button(onClick = { go() }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(t("unlock")) }
    }
}

@Composable
fun Login(auth: FirebaseAuth) {
    val ctx = LocalContext.current
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Nilkamal Orders", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(
            value = email, onValueChange = { email = it }, label = { Text("Email") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        OutlinedTextField(
            value = pass, onValueChange = { pass = it }, label = { Text("Password") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation()
        )
        if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)
        Button(
            onClick = {
                busy = true
                err = ""
                auth.signInWithEmailAndPassword(email.trim(), pass).addOnCompleteListener {
                    busy = false
                    if (!it.isSuccessful) {
                        err = it.exception?.localizedMessage ?: "Login failed"
                    } else {
                        Device.markLogin(ctx)
                        AuditLog.add("auth.login", "", Device.label())
                    }
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (busy) "…" else "Sign in") }
    }
}

@Composable
fun Main(auth: FirebaseAuth, uid: String, email: String, lang: String, onLang: (String) -> Unit) {
    val ctx = LocalContext.current
    var role by remember { mutableStateOf(Lease.cachedRole(ctx)) }
    var roleLoaded by remember { mutableStateOf(false) }
    LaunchedEffect(uid) {
        FirebaseFirestore.getInstance().collection("users").document(uid).get()
            .addOnSuccessListener {
                role = it.getString("role") ?: "worker"
                Lease.setRole(ctx, role)
                roleLoaded = true
            }
            .addOnFailureListener { roleLoaded = true }
    }
    val canManage = role == "admin" || role == "family"
    val cart = remember { CartState() }
    var tab by remember { mutableStateOf("shop") }

    LeaseGate(role, roleLoaded) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    "shop" -> ShopScreen(cart, email) { tab = "orders" }
                    "orders" -> OrdersScreen(role)
                    "products" -> ProductsScreen(role)
                    "security" -> SecurityScreen()
                    "history" -> HistoryScreen { tab = "account" }
                    "log" -> LogScreen { tab = "account" }
                    else -> AccountScreen(auth, email, role, lang, onLang) { tab = it }
                }
            }
            NavigationBar {
                (listOf("shop" to "🌸", "orders" to "📋") +
                    (if (canManage) listOf("products" to "🌷") else emptyList()) +
                    (if (role == "admin") listOf("security" to "🛡") else emptyList()) +
                    listOf("account" to "👤")).forEach { (k, icon) ->
                    NavigationBarItem(selected = tab == k, onClick = { tab = k }, icon = { Text(icon) }, label = { Text(t(k)) })
                }
            }
        }
    }
}

@Composable
fun AccountScreen(auth: FirebaseAuth, email: String, role: String, lang: String, onLang: (String) -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    var latest by remember { mutableStateOf<Updater.Info?>(null) }
    var progress by remember { mutableStateOf(-1) }

    fun check() {
        status = "Checking for updates…"
        scope.launch {
            val info = withContext(Dispatchers.IO) { runCatching { Updater.latest() }.getOrNull() }
            latest = info
            status = when {
                info == null -> "Could not check for updates (no internet?)"
                info.code > BuildConfig.VERSION_CODE -> "New version " + info.name + " is available"
                else -> "You have the latest version"
            }
        }
    }
    LaunchedEffect(Unit) { check() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(email, style = MaterialTheme.typography.titleLarge)
        Text("Role: $role")
        if (role == "admin") {
            OutlinedButton(onClick = { onOpen("history") }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("📜 " + t("history")) }
            OutlinedButton(onClick = { onOpen("log") }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("🗒 " + t("log")) }
            val last = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getLong("lastExport", 0L)
            val days = if (last == 0L) -1L else (System.currentTimeMillis() - last) / 86_400_000L
            Text(
                if (days < 0) t("csvNever") else t("csvAgo") + " " + days + " " + t("daysAgo"),
                color = if (days < 0 || days > 30) Color(0xFFB45309) else Color(0xFF475569)
            )
        }
        if ((role == "admin" || role == "family") && AppLock.available(ctx)) {
            var on by remember { mutableStateOf(AppLock.enabled(ctx)) }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(checked = on, onCheckedChange = { on = it; AppLock.setEnabled(ctx, it) })
                Text(t("appLock"))
            }
        }
        Text(t("language"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("en" to "English", "hi" to "हिंदी", "mr" to "मराठी").forEach { (k, label) ->
                Chip(label, lang == k) { onLang(k) }
            }
        }
        Text("App version: ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})")
        Text(status)
        val l = latest
        if (l != null && l.code > BuildConfig.VERSION_CODE) {
            Button(
                onClick = {
                    scope.launch {
                        progress = 0
                        val f = withContext(Dispatchers.IO) {
                            runCatching { Updater.download(ctx) { p -> progress = p } }.getOrNull()
                        }
                        progress = -1
                        if (f == null) {
                            status = "Download failed. Check your internet and try again."
                        } else if (!Updater.install(ctx, f)) {
                            status = "Allow 'Install unknown apps' for this app, then come back and tap Update again."
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Update to " + l.name) }
            if (progress >= 0) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
        }
        OutlinedButton(onClick = { check() }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(t("checkUpdates")) }
        OutlinedButton(onClick = { auth.signOut() }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(t("signOut")) }
    }
}
