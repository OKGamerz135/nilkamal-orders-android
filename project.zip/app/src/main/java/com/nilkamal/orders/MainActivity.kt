package com.nilkamal.orders

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFFBE123C))) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val auth = remember { FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { user = it.currentUser }
        auth.addAuthStateListener(l)
        onDispose { auth.removeAuthStateListener(l) }
    }
    Box(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        val u = user
        if (u == null) Login(auth) else Home(auth, u.uid, u.email ?: "")
    }
}

@Composable
fun Login(auth: FirebaseAuth) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Nilkamal Orders", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(
            value = email, onValueChange = { email = it }, label = { Text("Email") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        OutlinedTextField(
            value = pass, onValueChange = { pass = it }, label = { Text("Password") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation()
        )
        if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)
        Button(
            onClick = {
                busy = true
                err = ""
                auth.signInWithEmailAndPassword(email.trim(), pass).addOnCompleteListener {
                    busy = false
                    if (!it.isSuccessful) err = it.exception?.localizedMessage ?: "Login failed"
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (busy) "…" else "Sign in") }
    }
}

@Composable
fun Home(auth: FirebaseAuth, uid: String, email: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var role by remember { mutableStateOf("…") }
    var status by remember { mutableStateOf("") }
    var latest by remember { mutableStateOf<Updater.Info?>(null) }
    var progress by remember { mutableStateOf(-1) }

    LaunchedEffect(uid) {
        FirebaseFirestore.getInstance().collection("users").document(uid).get()
            .addOnSuccessListener { role = it.getString("role") ?: "worker" }
            .addOnFailureListener { role = "unknown" }
    }

    fun check() {
        status = "Checking for updates…"
        scope.launch {
            val info = withContext(Dispatchers.IO) { runCatching { Updater.latest() }.getOrNull() }
            latest = info
            status = when {
                info == null -> "Could not check for updates (no internet?)"
                info.code > BuildConfig.VERSION_CODE -> "New version " + info.name + " is available"
                else -> "You have the latest version"
            }
        }
    }
    LaunchedEffect(Unit) { check() }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Hello 👋", style = MaterialTheme.typography.headlineMedium)
        Text("Signed in as $email")
        Text("Role: $role")
        Text("App version: ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})")
        Text(status)
        val l = latest
        if (l != null && l.code > BuildConfig.VERSION_CODE) {
            Button(
                onClick = {
                    scope.launch {
                        progress = 0
                        val f = withContext(Dispatchers.IO) {
                            runCatching { Updater.download(ctx) { p -> progress = p } }.getOrNull()
                        }
                        progress = -1
                        if (f == null) {
                            status = "Download failed. Check your internet and try again."
                        } else if (!Updater.install(ctx, f)) {
                            status = "Allow 'Install unknown apps' for this app, then come back and tap Update again."
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Update to " + l.name) }
            if (progress >= 0) {
                LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
            }
        }
        OutlinedButton(onClick = { check() }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Check for updates") }
        OutlinedButton(onClick = { auth.signOut() }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Sign out") }
    }
}
