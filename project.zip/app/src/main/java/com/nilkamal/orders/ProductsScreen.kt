package com.nilkamal.orders

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Admin: add / hide / delete products and change prices. Family: change prices only.
@Composable
fun ProductsScreen(role: String) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val scope = rememberCoroutineScope()
    val isAdmin = role == "admin"
    val products = rememberProducts()
    var name by remember { mutableStateOf("") }
    var nameHi by remember { mutableStateOf("") }
    var nameMr by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("haar") }
    var price by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf<Product?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) uri = u }

    fun add() {
        val pr = price.toLongOrNull()
        val u = uri
        if (name.isBlank() || pr == null || u == null) {
            err = tr(lang, "fillAll")
            return
        }
        busy = true
        err = ""
        val label = name.trim() + " · " + rs(pr)
        scope.launch {
            val url = withContext(Dispatchers.IO) { runCatching { Cloud.upload(ctx, u) }.getOrNull() }
            if (url == null) {
                err = tr(lang, "uploadFail")
                busy = false
                return@launch
            }
            val data = hashMapOf<String, Any>(
                "name" to name.trim(), "name_hi" to nameHi.trim(), "name_mr" to nameMr.trim(), "category" to cat,
                "price" to pr, "imageUrl" to url, "active" to true, "createdAt" to FieldValue.serverTimestamp()
            )
            FirebaseFirestore.getInstance().collection("products").add(data)
                .addOnSuccessListener { AuditLog.add("product.add", it.id, label) }
            name = ""
            nameHi = ""
            nameMr = ""
            price = ""
            uri = null
            busy = false
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (isAdmin) {
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White)
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(t("addProduct"), fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(t("nameEn")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = nameHi, onValueChange = { nameHi = it }, label = { Text(t("nameHi")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = nameMr, onValueChange = { nameMr = it }, label = { Text(t("nameMr")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("haar", "bouquet", "loose", "other").forEach { c -> Chip(t(c), cat == c) { cat = c } }
                    }
                    OutlinedTextField(
                        value = price, onValueChange = { price = it.filter { c -> c.isDigit() } }, label = { Text(t("price") + " (₹)") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("📷 " + t("pickImage")) }
                    val pu = uri
                    if (pu != null) {
                        AsyncImage(model = pu, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(96.dp).clip(RoundedCornerShape(8.dp)))
                    }
                    if (err.isNotEmpty()) Text(err, color = Color(0xFFDC2626))
                    Button(onClick = { add() }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Text(if (busy) t("uploading") else t("addProduct"))
                    }
                }
            }
        }
        items(products, key = { it.id }) { p -> ProductRow(p, isAdmin) { deleting = p } }
    }

    val del = deleting
    if (del != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(t("delete")) },
            text = { Text(del.name + "\n" + t("confirmDel")) },
            confirmButton = {
                Button(onClick = {
                    FirebaseFirestore.getInstance().collection("products").document(del.id).delete()
                    AuditLog.add("product.delete", del.id, del.name)
                    deleting = null
                }) { Text(t("delete")) }
            },
            dismissButton = { OutlinedButton(onClick = { deleting = null }) { Text(t("cancel")) } }
        )
    }
}

@Composable
fun ProductRow(p: Product, isAdmin: Boolean, onDelete: () -> Unit) {
    val lang = LocalLang.current
    var price by remember(p.id, p.price) { mutableStateOf(p.price.toString()) }
    val newPrice = price.toLongOrNull()
    val changed = newPrice != null && newPrice != p.price
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White)
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp)).padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Photo(p.imageUrl, Modifier.size(72.dp).clip(RoundedCornerShape(8.dp)), 28)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(pname(p, lang) + (if (p.active) "" else " (" + t("hidden") + ")"), fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = price, onValueChange = { price = it.filter { c -> c.isDigit() } }, label = { Text("₹") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                )
                if (changed && newPrice != null) {
                    Button(onClick = {
                        FirebaseFirestore.getInstance().collection("products").document(p.id).update("price", newPrice)
                        AuditLog.add("product.price", p.id, p.name, listOf(Triple("price", p.price.toString(), newPrice.toString())))
                    }) { Text("💾") }
                }
            }
            if (isAdmin) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        FirebaseFirestore.getInstance().collection("products").document(p.id).update("active", !p.active)
                        AuditLog.add(if (p.active) "product.hide" else "product.show", p.id, p.name)
                    }) { Text(if (p.active) t("hide") else t("show")) }
                    OutlinedButton(onClick = onDelete) { Text("🗑") }
                }
            }
        }
    }
}
