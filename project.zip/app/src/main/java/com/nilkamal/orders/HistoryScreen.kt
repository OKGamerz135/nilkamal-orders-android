package com.nilkamal.orders

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val dateFmt = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault())
private fun fmtDate(d: Date?): String = if (d == null) "…" else dateFmt.format(d)
private fun csvCell(v: Any?): String = "\"" + (v?.toString() ?: "").replace("\"", "\"\"") + "\""

// Admin: download every order as a spreadsheet file and share it
fun exportCsv(ctx: Context) {
    FirebaseFirestore.getInstance().collection("orders").orderBy("createdAt", Query.Direction.DESCENDING).get()
        .addOnSuccessListener { snap ->
            val head = listOf("Order ID", "Taken by", "Created", "Customer", "Phone", "Items", "Total", "Advance", "Balance", "Due", "Status", "Notes", "Edited by", "Deleted by")
            val rows = snap.documents.map { it.toOrder() }.map { o ->
                listOf(
                    o.id, o.createdBy, fmtDate(o.createdAt), o.customerName, o.phone,
                    o.items.joinToString("; ") { it.name + " x" + it.qty + " @" + it.price },
                    o.total, o.advance, o.balance, fmtDate(o.dueAt), o.status, o.notes, o.editedBy, o.deletedBy
                )
            }
            val csv = "\uFEFF" + (listOf(head) + rows).joinToString("\n") { r -> r.joinToString(",") { csvCell(it) } }
            val dir = File(ctx.cacheDir, "export").apply { mkdirs() }
            val file = File(dir, "orders-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".csv")
            file.writeText(csv, Charsets.UTF_8)
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
            val send = Intent(Intent.ACTION_SEND)
            send.setType("text/csv")
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(send, "Export"))
            AuditLog.add("data.export", "", rows.size.toString() + " orders")
        }
}

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val orders = rememberHistory()
    var q by remember { mutableStateOf("") }
    var viewer by remember { mutableStateOf<String?>(null) }
    val list = orders.filter { q.isBlank() || it.customerName.contains(q, true) || it.phone.contains(q) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("←") }
            OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, label = { Text(t("search")) }, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { exportCsv(ctx) }) { Text("⬇ CSV") }
        }
        LazyColumn(contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(list, key = { it.id }) { o -> HistoryCard(o) { viewer = it } }
        }
    }
    val v = viewer
    if (v != null) PhotoViewer(v) { viewer = null }
}

@Composable
fun HistoryCard(o: Order, onPhoto: (String) -> Unit) {
    val deleted = o.status == "deleted"
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(if (deleted) Color(0xFFFEF2F2) else Color.White)
            .border(1.dp, if (deleted) Color(0xFFF87171) else Color(0xFFE2E8F0), shape).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(o.customerName + " · " + o.phone, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(
                if (deleted) t("deleted") else t(o.status), color = if (deleted) Color.White else Color.Unspecified,
                modifier = Modifier.background(if (deleted) Color(0xFFDC2626) else Color(0xFFE2E8F0), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 2.dp)
            )
        }
        Text(o.items.joinToString(", ") { it.name + " ×" + it.qty })
        if (o.refImage.isNotEmpty()) Photo(o.refImage, Modifier.size(72.dp).clip(RoundedCornerShape(8.dp)).clickable { onPhoto(o.refImage) }, 24)
        Text(t("total") + " " + rs(o.total) + " · " + t("advance") + " " + rs(o.advance) + " · " + t("balance") + " " + rs(o.balance))
        Text(t("createdBy") + ": " + o.createdBy + " · " + fmtDate(o.createdAt), fontSize = 13.sp, color = Color(0xFF475569))
        if (o.editedBy.isNotEmpty()) Text(t("edit") + ": " + o.editedBy + " · " + fmtDate(o.editedAt), fontSize = 13.sp, color = Color(0xFF475569))
        if (o.restoredBy.isNotEmpty()) Text(t("restore") + ": " + o.restoredBy + " · " + fmtDate(o.restoredAt), fontSize = 13.sp, color = Color(0xFF475569))
        if (deleted) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(t("deletedBy") + ": " + o.deletedBy + " · " + fmtDate(o.deletedAt), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFB91C1C), modifier = Modifier.weight(1f))
                OutlinedButton(onClick = {
                    val email = FirebaseAuth.getInstance().currentUser?.email ?: ""
                    FirebaseFirestore.getInstance().collection("orders").document(o.id)
                        .update(mapOf("status" to "new", "restoredBy" to email, "restoredAt" to FieldValue.serverTimestamp()))
                    AuditLog.add("order.restore", o.id, o.customerName + " · " + rs(o.total))
                }) { Text("↩ " + t("restore")) }
            }
        }
    }
}

private val FIELD = mapOf(
    "customerName" to "name", "phone" to "phone", "notes" to "notes", "dueAt" to "due", "total" to "total",
    "advance" to "advance", "items" to "cart", "status" to "status", "price" to "price"
)

@Composable
fun LogScreen(onBack: () -> Unit) {
    val lang = LocalLang.current
    val logs = rememberLogs()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("←") }
            Text(t("log"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        if (logs.isEmpty()) Text(t("empty"), modifier = Modifier.padding(16.dp))
        LazyColumn(contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(logs, key = { it.id }) { l ->
                val shape = RoundedCornerShape(12.dp)
                val danger = l.action.contains("delete")
                Column(
                    Modifier.fillMaxWidth().clip(shape).background(Color.White)
                        .border(1.dp, if (danger) Color(0xFFF87171) else Color(0xFFE2E8F0), shape).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(l.by, fontWeight = FontWeight.Bold)
                    Text(tr(lang, "act_" + l.action.replace('.', '_')) + " " + l.label)
                    Text(fmtDate(l.at), fontSize = 12.sp, color = Color(0xFF64748B))
                    l.changes.forEach { c ->
                        Text(tr(lang, FIELD[c.first] ?: c.first) + ": " + tr(lang, c.second) + " → " + tr(lang, c.third), fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
