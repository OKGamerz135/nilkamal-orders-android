package com.nilkamal.orders

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MAX_EMPLOYEE_RETRIES = 3

// Strip shown above every screen while orders are waiting, refused, or belong to another account
@Composable
fun UnsentBanner(uid: String, onOpen: () -> Unit) {
    val ctx = LocalContext.current
    val ver = Outbox.version
    val mine = remember(ver, uid) { Outbox.forOwner(ctx, uid) }
    val others = remember(ver, uid) { Outbox.otherOwners(ctx, uid) }
    if (mine.isNotEmpty() || others.isNotEmpty()) {
        val refused = mine.count { it.status == "refused" }
        val text = when {
            refused > 0 -> "⚠ " + refused + " " + t("unsentRefused")
            mine.isNotEmpty() -> "⏳ " + mine.size + " " + t("unsentWaiting")
            else -> "ℹ " + t("otherAccounts") + ": " + others.entries.joinToString(", ") { it.key + " (" + it.value + ")" }
        }
        Text(
            text + "  ·  " + t("tapOpen"), fontWeight = FontWeight.SemiBold,
            modifier = Modifier.fillMaxWidth().background(if (refused > 0) Color(0xFFFECACA) else Color(0xFFFEF3C7))
                .clickable(onClick = onOpen).padding(10.dp)
        )
    }
}

@Composable
fun UnsentScreen(uid: String, role: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val ver = Outbox.version
    val staff = role == "admin" || role == "family"
    val mine = remember(ver, uid) { Outbox.forOwner(ctx, uid) }
    val others = remember(ver, uid) { Outbox.otherOwners(ctx, uid) }
    var discarding by remember { mutableStateOf<OutboxEntry?>(null) }
    val fmt = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }
    val shape = RoundedCornerShape(12.dp)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = onBack) { Text("←") }
                Text(t("unsentTitle"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (mine.isEmpty()) item { Text(t("empty")) }
        items(mine, key = { it.id }) { e ->
            val refused = e.status == "refused"
            val stuck = !refused && System.currentTimeMillis() - e.savedAtMs > 7 * 86_400_000L
            Column(
                Modifier.fillMaxWidth().clip(shape).background(if (refused) Color(0xFFFEF2F2) else Color.White)
                    .border(1.dp, if (refused) Color(0xFFF87171) else Color(0xFFE2E8F0), shape).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(e.customerName + " · " + rs(e.total), fontWeight = FontWeight.Bold)
                Text(Outbox.itemNames(e))
                Text(t("due") + ": " + fmt.format(Date(e.dueAtMs)) + " · " + e.phone, fontSize = 13.sp)
                Text(t("account") + ": " + e.ownerEmail + " · " + t("savedAt") + " " + fmt.format(Date(e.savedAtMs)), fontSize = 13.sp, color = Color(0xFF475569))
                Text(
                    if (refused) "❌ " + t("stRefused") + " (" + e.lastError + ") · " + t("attemptsLbl") + " " + e.attempts else "⏳ " + t("stWaiting"),
                    fontWeight = FontWeight.SemiBold, color = if (refused) Color(0xFFB91C1C) else Color(0xFFB45309)
                )
                if (refused) Text(t("refusedHelp"), fontSize = 13.sp)
                if (stuck) Text(t("stuckDays"), fontSize = 13.sp, color = Color(0xFFB45309))
                val canRetry = refused && (staff || e.attempts < MAX_EMPLOYEE_RETRIES)
                if (refused && !canRetry) Text(t("needsAdmin"), fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (canRetry) Button(onClick = { Outbox.retry(ctx, e.id) }) { Text(t("retry")) }
                    OutlinedButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND)
                        send.setType("text/plain")
                        send.putExtra(Intent.EXTRA_TEXT, Outbox.summary(e) + " (" + fmt.format(Date(e.dueAtMs)) + ")")
                        ctx.startActivity(Intent.createChooser(send, t("shareDetails")))
                    }) { Text(t("shareDetails")) }
                    if (refused && staff) OutlinedButton(onClick = { discarding = e }) { Text(t("discard")) }
                }
            }
        }
        if (others.isNotEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().clip(shape).background(Color(0xFFF1F5F9)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(t("otherAccounts"), fontWeight = FontWeight.Bold)
                    others.forEach { (mail, n) -> Text(mail + " — " + n) }
                }
            }
        }
        val bad = Outbox.unreadableCount(ctx)
        if (bad > 0) item { Text(t("unreadableKept") + " (" + bad + ")", fontSize = 13.sp, color = Color(0xFFB91C1C)) }
    }

    val d = discarding
    if (d != null) {
        AlertDialog(
            onDismissRequest = { discarding = null },
            title = { Text(t("discard")) },
            text = { Text(Outbox.summary(d) + "\n\n" + t("discardConfirm")) },
            confirmButton = { Button(onClick = { Outbox.discard(ctx, d); discarding = null }) { Text(t("discard")) } },
            dismissButton = { OutlinedButton(onClick = { discarding = null }) { Text(t("cancel")) } }
        )
    }
}
