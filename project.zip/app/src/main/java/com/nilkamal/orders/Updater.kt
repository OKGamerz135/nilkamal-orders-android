package com.nilkamal.orders

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException

// Looks for a newer APK in the GitHub Releases of the Android repo, downloads it and asks Android to install it.
object Updater {
    data class Info(val code: Int, val name: String)

    private val client = OkHttpClient()

    fun latest(): Info? {
        val req = Request.Builder().url(BuildConfig.UPDATE_BASE + "version.json").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return null
            val text = r.body?.string() ?: return null
            val j = JSONObject(text)
            return Info(j.getInt("versionCode"), j.getString("versionName"))
        }
    }

    fun download(ctx: Context, onProgress: (Int) -> Unit): File {
        val dir = File(ctx.cacheDir, "apk").apply { mkdirs() }
        val out = File(dir, "app.apk")
        val req = Request.Builder().url(BuildConfig.UPDATE_BASE + "app.apk").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP " + r.code)
            val body = r.body ?: throw IOException("Empty download")
            val total = body.contentLength()
            body.byteStream().use { input ->
                out.outputStream().use { o ->
                    val buf = ByteArray(32 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100 / total).toInt())
                    }
                }
            }
        }
        return out
    }

    // Returns false if the person still has to allow "Install unknown apps" for this app
    fun install(ctx: Context, apk: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", apk)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }
}
