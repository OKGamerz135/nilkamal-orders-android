package com.nilkamal.orders

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf

val LocalLang = compositionLocalOf { "en" }

@Composable
fun t(key: String): String = tr(LocalLang.current, key)

fun tr(lang: String, key: String): String =
    S[lang]?.get(key) ?: S.getValue("en")[key] ?: key

private val S: Map<String, Map<String, String>> = mapOf(
    "en" to mapOf(
        "shop" to "Shop", "orders" to "Orders", "account" to "Account", "all" to "All", "haar" to "Haar",
        "bouquet" to "Bouquets", "loose" to "Loose flowers", "other" to "Other", "searchProduct" to "Search products",
        "select" to "Select", "cancel" to "Cancel", "addToCart" to "Add to cart", "inCart" to "In cart", "cart" to "Cart",
        "empty" to "Nothing here yet", "qty" to "Qty", "itemsTotal" to "Items total", "customItem" to "Custom item",
        "itemName" to "Item name", "addBtn" to "Add", "name" to "Customer name", "phone" to "Phone (10 digits)",
        "due" to "Due date & time", "pickDateTime" to "Pick date & time", "total" to "Total", "advance" to "Advance",
        "balance" to "Balance", "notes" to "Customization notes", "save" to "Save order", "saved" to "Order saved",
        "err" to "Please check: name, 10-digit phone, due time, items, advance ≤ total",
        "new" to "New", "progress" to "In progress", "ready" to "Ready", "delivered" to "Delivered",
        "moveTo" to "Move to", "markPaid" to "Mark balance paid", "call" to "Call", "whatsapp" to "WhatsApp",
        "active" to "Active", "today" to "Today", "unpaid" to "Unpaid", "overdue" to "Overdue", "dueSoon" to "Due soon",
        "paid" to "Paid", "closeBtn" to "Close", "back" to "Back to products", "clear" to "Clear cart",
        "listPrice" to "Usual price", "language" to "Language", "signOut" to "Sign out", "checkUpdates" to "Check for updates",
        "tapZoom" to "Pinch or double-tap the photo to zoom", "price" to "Price"
    ),
    "hi" to mapOf(
        "shop" to "दुकान", "orders" to "ऑर्डर", "account" to "खाता", "all" to "सभी", "haar" to "हार",
        "bouquet" to "बुके", "loose" to "खुले फूल", "other" to "अन्य", "searchProduct" to "उत्पाद खोजें",
        "select" to "चुनें", "cancel" to "रद्द करें", "addToCart" to "कार्ट में डालें", "inCart" to "कार्ट में", "cart" to "कार्ट",
        "empty" to "अभी कुछ नहीं है", "qty" to "मात्रा", "itemsTotal" to "सामान का कुल", "customItem" to "अलग सामान",
        "itemName" to "सामान का नाम", "addBtn" to "जोड़ें", "name" to "ग्राहक का नाम", "phone" to "फ़ोन (10 अंक)",
        "due" to "डिलीवरी की तारीख व समय", "pickDateTime" to "तारीख व समय चुनें", "total" to "कुल रकम", "advance" to "अग्रिम",
        "balance" to "बाकी", "notes" to "विशेष निर्देश", "save" to "ऑर्डर सेव करें", "saved" to "ऑर्डर सेव हुआ",
        "err" to "कृपया जांचें: नाम, 10 अंक का फ़ोन, समय, सामान, अग्रिम ≤ कुल",
        "new" to "नया", "progress" to "तैयार हो रहा", "ready" to "तैयार", "delivered" to "डिलीवर हुआ",
        "moveTo" to "आगे", "markPaid" to "बाकी रकम मिली", "call" to "कॉल", "whatsapp" to "व्हाट्सऐप",
        "active" to "चालू", "today" to "आज", "unpaid" to "बाकी वाले", "overdue" to "देरी", "dueSoon" to "जल्द देना है",
        "paid" to "चुकाया", "closeBtn" to "बंद करें", "back" to "उत्पादों पर वापस", "clear" to "कार्ट खाली करें",
        "listPrice" to "सामान्य कीमत", "language" to "भाषा", "signOut" to "लॉग आउट", "checkUpdates" to "अपडेट देखें",
        "tapZoom" to "फोटो को ज़ूम करने के लिए पिंच या डबल टैप करें", "price" to "कीमत"
    ),
    "mr" to mapOf(
        "shop" to "दुकान", "orders" to "ऑर्डर", "account" to "खाते", "all" to "सर्व", "haar" to "हार",
        "bouquet" to "बुके", "loose" to "सुटी फुले", "other" to "इतर", "searchProduct" to "उत्पादन शोधा",
        "select" to "निवडा", "cancel" to "रद्द करा", "addToCart" to "कार्टमध्ये टाका", "inCart" to "कार्टमध्ये", "cart" to "कार्ट",
        "empty" to "अजून काही नाही", "qty" to "संख्या", "itemsTotal" to "वस्तूंची एकूण", "customItem" to "वेगळी वस्तू",
        "itemName" to "वस्तूचे नाव", "addBtn" to "जोडा", "name" to "ग्राहकाचे नाव", "phone" to "फोन (१० अंक)",
        "due" to "डिलिव्हरीची तारीख व वेळ", "pickDateTime" to "तारीख व वेळ निवडा", "total" to "एकूण रक्कम", "advance" to "आगाऊ",
        "balance" to "बाकी", "notes" to "विशेष सूचना", "save" to "ऑर्डर सेव्ह करा", "saved" to "ऑर्डर सेव्ह झाली",
        "err" to "कृपया तपासा: नाव, १० अंकी फोन, वेळ, वस्तू, आगाऊ ≤ एकूण",
        "new" to "नवीन", "progress" to "तयार होत आहे", "ready" to "तयार", "delivered" to "डिलिव्हर झाले",
        "moveTo" to "पुढे", "markPaid" to "बाकी रक्कम मिळाली", "call" to "कॉल", "whatsapp" to "व्हॉट्सअ‍ॅप",
        "active" to "चालू", "today" to "आज", "unpaid" to "बाकी असलेले", "overdue" to "उशीर", "dueSoon" to "लवकर द्यायचे",
        "paid" to "भरले", "closeBtn" to "बंद करा", "back" to "उत्पादनांकडे परत", "clear" to "कार्ट रिकामे करा",
        "listPrice" to "नेहमीची किंमत", "language" to "भाषा", "signOut" to "लॉग आउट", "checkUpdates" to "अपडेट तपासा",
        "tapZoom" to "झूम करण्यासाठी पिंच किंवा डबल टॅप करा", "price" to "किंमत"
    )
)
