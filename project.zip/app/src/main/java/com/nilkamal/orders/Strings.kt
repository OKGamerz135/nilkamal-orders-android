package com.nilkamal.orders

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf

val LocalLang = compositionLocalOf { "en" }

@Composable
fun t(key: String): String = tr(LocalLang.current, key)

fun tr(lang: String, key: String): String =
    S[lang]?.get(key) ?: SX[lang]?.get(key) ?: S.getValue("en")[key] ?: SX.getValue("en")[key] ?: key

private val S: Map<String, Map<String, String>> = mapOf(
    "en" to mapOf(
        "shop" to "Shop", "orders" to "Orders", "account" to "Account", "all" to "All", "haar" to "Haar",
        "bouquet" to "Bouquets", "loose" to "Loose flowers", "other" to "Other", "searchProduct" to "Search products",
        "select" to "Select", "cancel" to "Cancel", "addToCart" to "Add to cart", "inCart" to "In cart", "cart" to "Cart",
        "empty" to "Nothing here yet", "qty" to "Qty", "itemsTotal" to "Items total", "customItem" to "Custom item",
        "itemName" to "Item name", "addBtn" to "Add", "name" to "Customer name", "phone" to "Phone (10 digits)",
        "due" to "Due date & time", "pickDateTime" to "Pick date & time", "total" to "Total", "advance" to "Advance",
        "balance" to "Balance", "notes" to "Customization notes", "save" to "Save order", "saved" to "Order saved",
        "err" to "Please check: name, 10-digit phone, due time, items, advance ≤ total",
        "new" to "New", "progress" to "In progress", "ready" to "Ready", "delivered" to "Delivered",
        "moveTo" to "Move to", "markPaid" to "Mark balance paid", "call" to "Call", "whatsapp" to "WhatsApp",
        "active" to "Active", "today" to "Today", "unpaid" to "Unpaid", "overdue" to "Overdue", "dueSoon" to "Due soon",
        "paid" to "Paid", "closeBtn" to "Close", "back" to "Back to products", "clear" to "Clear cart",
        "listPrice" to "Usual price", "language" to "Language", "signOut" to "Sign out", "checkUpdates" to "Check for updates",
        "tapZoom" to "Pinch or double-tap the photo to zoom", "price" to "Price"
    ),
    "hi" to mapOf(
        "shop" to "दुकान", "orders" to "ऑर्डर", "account" to "खाता", "all" to "सभी", "haar" to "हार",
        "bouquet" to "बुके", "loose" to "खुले फूल", "other" to "अन्य", "searchProduct" to "उत्पाद खोजें",
        "select" to "चुनें", "cancel" to "रद्द करें", "addToCart" to "कार्ट में डालें", "inCart" to "कार्ट में", "cart" to "कार्ट",
        "empty" to "अभी कुछ नहीं है", "qty" to "मात्रा", "itemsTotal" to "सामान का कुल", "customItem" to "अलग सामान",
        "itemName" to "सामान का नाम", "addBtn" to "जोड़ें", "name" to "ग्राहक का नाम", "phone" to "फ़ोन (10 अंक)",
        "due" to "डिलीवरी की तारीख व समय", "pickDateTime" to "तारीख व समय चुनें", "total" to "कुल रकम", "advance" to "अग्रिम",
        "balance" to "बाकी", "notes" to "विशेष निर्देश", "save" to "ऑर्डर सेव करें", "saved" to "ऑर्डर सेव हुआ",
        "err" to "कृपया जांचें: नाम, 10 अंक का फ़ोन, समय, सामान, अग्रिम ≤ कुल",
        "new" to "नया", "progress" to "तैयार हो रहा", "ready" to "तैयार", "delivered" to "डिलीवर हुआ",
        "moveTo" to "आगे", "markPaid" to "बाकी रकम मिली", "call" to "कॉल", "whatsapp" to "व्हाट्सऐप",
        "active" to "चालू", "today" to "आज", "unpaid" to "बाकी वाले", "overdue" to "देरी", "dueSoon" to "जल्द देना है",
        "paid" to "चुकाया", "closeBtn" to "बंद करें", "back" to "उत्पादों पर वापस", "clear" to "कार्ट खाली करें",
        "listPrice" to "सामान्य कीमत", "language" to "भाषा", "signOut" to "लॉग आउट", "checkUpdates" to "अपडेट देखें",
        "tapZoom" to "फोटो को ज़ूम करने के लिए पिंच या डबल टैप करें", "price" to "कीमत"
    ),
    "mr" to mapOf(
        "shop" to "दुकान", "orders" to "ऑर्डर", "account" to "खाते", "all" to "सर्व", "haar" to "हार",
        "bouquet" to "बुके", "loose" to "सुटी फुले", "other" to "इतर", "searchProduct" to "उत्पादन शोधा",
        "select" to "निवडा", "cancel" to "रद्द करा", "addToCart" to "कार्टमध्ये टाका", "inCart" to "कार्टमध्ये", "cart" to "कार्ट",
        "empty" to "अजून काही नाही", "qty" to "संख्या", "itemsTotal" to "वस्तूंची एकूण", "customItem" to "वेगळी वस्तू",
        "itemName" to "वस्तूचे नाव", "addBtn" to "जोडा", "name" to "ग्राहकाचे नाव", "phone" to "फोन (१० अंक)",
        "due" to "डिलिव्हरीची तारीख व वेळ", "pickDateTime" to "तारीख व वेळ निवडा", "total" to "एकूण रक्कम", "advance" to "आगाऊ",
        "balance" to "बाकी", "notes" to "विशेष सूचना", "save" to "ऑर्डर सेव्ह करा", "saved" to "ऑर्डर सेव्ह झाली",
        "err" to "कृपया तपासा: नाव, १० अंकी फोन, वेळ, वस्तू, आगाऊ ≤ एकूण",
        "new" to "नवीन", "progress" to "तयार होत आहे", "ready" to "तयार", "delivered" to "डिलिव्हर झाले",
        "moveTo" to "पुढे", "markPaid" to "बाकी रक्कम मिळाली", "call" to "कॉल", "whatsapp" to "व्हॉट्सअ‍ॅप",
        "active" to "चालू", "today" to "आज", "unpaid" to "बाकी असलेले", "overdue" to "उशीर", "dueSoon" to "लवकर द्यायचे",
        "paid" to "भरले", "closeBtn" to "बंद करा", "back" to "उत्पादनांकडे परत", "clear" to "कार्ट रिकामे करा",
        "listPrice" to "नेहमीची किंमत", "language" to "भाषा", "signOut" to "लॉग आउट", "checkUpdates" to "अपडेट तपासा",
        "tapZoom" to "झूम करण्यासाठी पिंच किंवा डबल टॅप करा", "price" to "किंमत"
    )
)

private val SX: Map<String, Map<String, String>> = mapOf(
    "en" to mapOf(
        "products" to "Products", "history" to "History", "log" to "Log book", "edit" to "Edit", "delete" to "Delete",
        "deleteOrder" to "Delete order", "deleted" to "Deleted", "createdBy" to "Taken by", "deletedBy" to "Deleted by",
        "search" to "Search name or phone", "confirmDelOrder" to "Delete this order? It stays in History.", "confirmDel" to "Delete this?",
        "saveChanges" to "Save changes", "restore" to "Restore", "exportCsv" to "Export CSV", "hide" to "Hide", "show" to "Show",
        "hidden" to "Hidden", "addProduct" to "Add product", "nameEn" to "Name (English)", "nameHi" to "Name (Hindi)",
        "nameMr" to "Name (Marathi)", "pickImage" to "Choose photo", "uploading" to "Uploading…",
        "uploadFail" to "Photo upload failed. Check internet or remove the photo.", "refPhoto" to "Reference photo (optional)",
        "dueToday" to "Due today", "advanceToday" to "Advance taken today", "balancePending" to "Balance pending",
        "addItem" to "Add item", "status" to "Status", "fillAll" to "Please fill the name and price and choose a photo",
        "act_order_create" to "created order", "act_order_edit" to "edited order", "act_order_status" to "changed status of",
        "act_order_paid" to "marked balance paid for", "act_order_delete" to "deleted order", "act_order_restore" to "restored order",
        "act_product_add" to "added product", "act_product_price" to "changed price of", "act_product_hide" to "hid product",
        "act_product_show" to "unhid product", "act_product_delete" to "deleted product", "act_data_export" to "exported to CSV:",
        "act_auth_login" to "signed in", "act_product_edit" to "edited product", "chooseCat" to "Please select a category",
        "missingNames" to "Hindi or Marathi name missing", "category" to "Category", "photo" to "Photo", "changePhoto" to "Change photo"
    ),
    "hi" to mapOf(
        "products" to "उत्पाद", "history" to "इतिहास", "log" to "लॉग बुक", "edit" to "बदलें", "delete" to "हटाएं",
        "deleteOrder" to "ऑर्डर हटाएं", "deleted" to "हटाया गया", "createdBy" to "ऑर्डर लेने वाला", "deletedBy" to "हटाने वाला",
        "search" to "नाम या फ़ोन खोजें", "confirmDelOrder" to "यह ऑर्डर हटाएं? यह इतिहास में रहेगा।", "confirmDel" to "हटाना है?",
        "saveChanges" to "बदलाव सेव करें", "restore" to "वापस लाएं", "exportCsv" to "CSV डाउनलोड", "hide" to "छुपाएं", "show" to "दिखाएं",
        "hidden" to "छुपा हुआ", "addProduct" to "उत्पाद जोड़ें", "nameEn" to "नाम (अंग्रेज़ी)", "nameHi" to "नाम (हिंदी)",
        "nameMr" to "नाम (मराठी)", "pickImage" to "फोटो चुनें", "uploading" to "अपलोड हो रहा…",
        "uploadFail" to "फोटो अपलोड नहीं हुआ। इंटरनेट देखें या फोटो हटाएं।", "refPhoto" to "रेफरेंस फोटो (वैकल्पिक)",
        "dueToday" to "आज देना है", "advanceToday" to "आज का अग्रिम", "balancePending" to "बकाया रकम",
        "addItem" to "सामान जोड़ें", "status" to "स्थिति", "fillAll" to "कृपया नाम, कीमत भरें और फोटो चुनें",
        "act_order_create" to "ने ऑर्डर बनाया", "act_order_edit" to "ने ऑर्डर बदला", "act_order_status" to "ने स्थिति बदली",
        "act_order_paid" to "ने बाकी रकम चुकाई दर्ज की", "act_order_delete" to "ने ऑर्डर हटाया", "act_order_restore" to "ने ऑर्डर वापस लाया",
        "act_product_add" to "ने उत्पाद जोड़ा", "act_product_price" to "ने कीमत बदली", "act_product_hide" to "ने उत्पाद छुपाया",
        "act_product_show" to "ने उत्पाद दिखाया", "act_product_delete" to "ने उत्पाद हटाया", "act_data_export" to "ने CSV निकाला:",
        "act_auth_login" to "ने लॉग इन किया", "act_product_edit" to "ने उत्पाद बदला", "chooseCat" to "कृपया श्रेणी चुनें",
        "missingNames" to "हिंदी या मराठी नाम नहीं है", "category" to "श्रेणी", "photo" to "फोटो", "changePhoto" to "फोटो बदलें"
    ),
    "mr" to mapOf(
        "products" to "उत्पादने", "history" to "इतिहास", "log" to "लॉग बुक", "edit" to "बदल", "delete" to "काढा",
        "deleteOrder" to "ऑर्डर काढा", "deleted" to "काढली", "createdBy" to "ऑर्डर घेणारा", "deletedBy" to "काढणारा",
        "search" to "नाव किंवा फोन शोधा", "confirmDelOrder" to "ही ऑर्डर काढायची? ती इतिहासात राहील.", "confirmDel" to "काढायचे?",
        "saveChanges" to "बदल सेव्ह करा", "restore" to "परत आणा", "exportCsv" to "CSV डाउनलोड", "hide" to "लपवा", "show" to "दाखवा",
        "hidden" to "लपवलेले", "addProduct" to "उत्पादन जोडा", "nameEn" to "नाव (इंग्रजी)", "nameHi" to "नाव (हिंदी)",
        "nameMr" to "नाव (मराठी)", "pickImage" to "फोटो निवडा", "uploading" to "अपलोड होत आहे…",
        "uploadFail" to "फोटो अपलोड झाला नाही. इंटरनेट तपासा किंवा फोटो काढा.", "refPhoto" to "संदर्भ फोटो (ऐच्छिक)",
        "dueToday" to "आज द्यायचे", "advanceToday" to "आजचे आगाऊ", "balancePending" to "बाकी रक्कम",
        "addItem" to "वस्तू जोडा", "status" to "स्थिती", "fillAll" to "कृपया नाव, किंमत भरा आणि फोटो निवडा",
        "act_order_create" to "ने ऑर्डर बनवली", "act_order_edit" to "ने ऑर्डर बदलली", "act_order_status" to "ने स्थिती बदलली",
        "act_order_paid" to "ने बाकी रक्कम भरल्याची नोंद केली", "act_order_delete" to "ने ऑर्डर काढली", "act_order_restore" to "ने ऑर्डर परत आणली",
        "act_product_add" to "ने उत्पादन जोडले", "act_product_price" to "ने किंमत बदलली", "act_product_hide" to "ने उत्पादन लपवले",
        "act_product_show" to "ने उत्पादन दाखवले", "act_product_delete" to "ने उत्पादन काढले", "act_data_export" to "ने CSV काढले:",
        "act_auth_login" to "ने लॉग इन केले", "act_product_edit" to "ने उत्पादन बदलले", "chooseCat" to "कृपया वर्ग निवडा",
        "missingNames" to "हिंदी किंवा मराठी नाव नाही", "category" to "वर्ग", "photo" to "फोटो", "changePhoto" to "फोटो बदला"
    )
)
