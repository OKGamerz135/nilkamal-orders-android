package com.nilkamal.orders

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import org.json.JSONArray
import org.json.JSONObject
import java.util.Date

data class OutboxEntry(
    val id: String, val ownerUid: String, val ownerEmail: String, val customerName: String, val phone: String,
    val notes: String, val refImage: String, val itemsJson: String, val total: Long, val advance: Long,
    val dueAtMs: Long, val clientAtMs: Long, val bargainsJson: String,
    val status: String, // "pending" = waiting for internet / server, "refused" = the server refused it
    val attempts: Int, val lastError: String, val savedAtMs: Long, val logged: Boolean
)

// Every new order is written here (to disk, synchronously) BEFORE it is sent.
// It is removed only when the server confirms it, or when an admin/family member discards it on purpose.
object Outbox {
    var version by mutableStateOf(0) // screens read this so they redraw when the outbox changes

    private val lock = Any()
    private val inFlight = HashSet<String>()
    private val permanent = setOf(
        FirebaseFirestoreException.Code.PERMISSION_DENIED, FirebaseFirestoreException.Code.INVALID_ARGUMENT,
        FirebaseFirestoreException.Code.FAILED_PRECONDITION, FirebaseFirestoreException.Code.OUT_OF_RANGE,
        FirebaseFirestoreException.Code.UNIMPLEMENTED, FirebaseFirestoreException.Code.ALREADY_EXISTS,
        FirebaseFirestoreException.Code.NOT_FOUND
    )

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("outbox", Context.MODE_PRIVATE)

    private fun toJson(e: OutboxEntry): JSONObject = JSONObject()
        .put("id", e.id).put("ownerUid", e.ownerUid).put("ownerEmail", e.ownerEmail).put("customerName", e.customerName)
        .put("phone", e.phone).put("notes", e.notes).put("refImage", e.refImage).put("items", JSONArray(e.itemsJson))
        .put("total", e.total).put("advance", e.advance).put("dueAtMs", e.dueAtMs).put("clientAtMs", e.clientAtMs)
        .put("bargains", JSONArray(e.bargainsJson)).put("status", e.status).put("attempts", e.attempts)
        .put("lastError", e.lastError).put("savedAtMs", e.savedAtMs).put("logged", e.logged)

    private fun fromJson(o: JSONObject): OutboxEntry = OutboxEntry(
        id = o.getString("id"), ownerUid = o.getString("ownerUid"), ownerEmail = o.getString("ownerEmail"),
        customerName = o.optString("customerName"), phone = o.optString("phone"), notes = o.optString("notes"),
        refImage = o.optString("refImage"), itemsJson = o.getJSONArray("items").toString(),
        total = o.getLong("total"), advance = o.getLong("advance"), dueAtMs = o.getLong("dueAtMs"),
        clientAtMs = o.getLong("clientAtMs"), bargainsJson = o.optJSONArray("bargains")?.toString() ?: "[]",
        status = o.optString("status", "pending"), attempts = o.optInt("attempts", 0), lastError = o.optString("lastError"),
        savedAtMs = o.optLong("savedAtMs", 0L), logged = o.optBoolean("logged", false)
    )

    private fun readAll(ctx: Context): MutableList<OutboxEntry> {
        val p = prefs(ctx)
        val arr = try { JSONArray(p.getString("entries", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        val out = ArrayList<OutboxEntry>()
        for (i in 0 until arr.length()) {
            try {
                out.add(fromJson(arr.getJSONObject(i)))
            } catch (e: Exception) {
                // an unreadable entry is kept aside, never thrown away
                val kept = p.getString("unreadable", "[]") ?: "[]"
                p.edit().putString("unreadable", JSONArray(kept).put(arr.opt(i)).toString()).commit()
            }
        }
        return out
    }

    private fun writeAll(ctx: Context, list: List<OutboxEntry>): Boolean =
        prefs(ctx).edit().putString("entries", JSONArray(list.map { toJson(it) }).toString()).commit()

    fun unreadableCount(ctx: Context): Int = try { JSONArray(prefs(ctx).getString("unreadable", "[]") ?: "[]").length() } catch (e: Exception) { 0 }
    fun all(ctx: Context): List<OutboxEntry> = synchronized(lock) { readAll(ctx) }
    fun forOwner(ctx: Context, uid: String): List<OutboxEntry> = all(ctx).filter { it.ownerUid == uid }
    fun countFor(ctx: Context, uid: String): Int = forOwner(ctx, uid).size
    fun otherOwners(ctx: Context, uid: String): Map<String, Int> =
        all(ctx).filter { it.ownerUid != uid }.groupBy { it.ownerEmail }.mapValues { it.value.size }

    // false = could not be written to disk: the caller must keep the cart and tell the person
    fun add(ctx: Context, e: OutboxEntry): Boolean {
        val ok = synchronized(lock) {
            val list = readAll(ctx)
            if (list.any { it.id == e.id }) true else { list.add(e); writeAll(ctx, list) }
        }
        if (ok) version++
        return ok
    }

    private fun replace(ctx: Context, e: OutboxEntry) {
        synchronized(lock) {
            val list = readAll(ctx)
            val i = list.indexOfFirst { it.id == e.id }
            if (i >= 0) { list[i] = e; writeAll(ctx, list) }
        }
    }

    private fun release(id: String) { synchronized(lock) { inFlight.remove(id) } }

    private fun buildMap(e: OutboxEntry): HashMap<String, Any> {
        val arr = JSONArray(e.itemsJson)
        val items = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            mapOf(
                "productId" to o.optString("productId"), "name" to o.optString("name"),
                "name_hi" to o.optString("name_hi"), "name_mr" to o.optString("name_mr"),
                "price" to o.getLong("price"), "defPrice" to o.getLong("defPrice"), "qty" to o.getLong("qty"),
                "imageUrl" to o.optString("imageUrl")
            )
        }
        return hashMapOf(
            "customerName" to e.customerName, "phone" to e.phone, "notes" to e.notes, "refImage" to e.refImage,
            "items" to items, "total" to e.total, "advance" to e.advance, "balance" to e.total - e.advance,
            "dueAt" to Timestamp(Date(e.dueAtMs)), "status" to "new", "createdAt" to FieldValue.serverTimestamp(),
            "createdBy" to e.ownerEmail, "clientAt" to Timestamp(Date(e.clientAtMs))
        )
    }

    fun bargainsOf(json: String): List<Triple<String, String, String>> {
        val arr = try { JSONArray(json) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Triple(o.optString("f"), o.optString("from"), o.optString("to"))
        }
    }

    fun itemNames(e: OutboxEntry): String {
        val arr = try { JSONArray(e.itemsJson) } catch (ex: Exception) { JSONArray() }
        return (0 until arr.length()).joinToString(", ") { i ->
            val o = arr.getJSONObject(i)
            o.optString("name") + " ×" + o.optLong("qty", 1L)
        }
    }

    fun summary(e: OutboxEntry): String = e.customerName + " · " + rs(e.total) + " · " + itemNames(e) + " · " + e.phone

    // "Sent" is only ever set here, after the server confirmed it
    private fun markSynced(app: Context, e: OutboxEntry) {
        val removed = synchronized(lock) {
            val list = readAll(app)
            val had = list.removeAll { it.id == e.id }
            if (had) writeAll(app, list)
            had
        }
        if (!removed) return
        version++
        if (!e.logged) AuditLog.add("order.create", e.id, e.customerName + " · " + rs(e.total), bargainsOf(e.bargainsJson))
    }

    private fun refuse(app: Context, e: OutboxEntry, code: String) {
        replace(app, e.copy(status = "refused", attempts = e.attempts + 1, lastError = code))
        version++
    }

    // The same order ID is used for every attempt, so a retry can never create a second order
    fun submit(ctx: Context, id: String) {
        val app = ctx.applicationContext
        val e = synchronized(lock) {
            if (inFlight.contains(id)) null else readAll(app).firstOrNull { it.id == id }?.also { inFlight.add(id) }
        } ?: return
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null || user.uid != e.ownerUid) {
            release(id)
            return
        }
        FirebaseFirestore.getInstance().collection("orders").document(e.id).set(buildMap(e))
            .addOnSuccessListener {
                markSynced(app, e)
                release(id)
            }
            .addOnFailureListener { ex -> handleFailure(app, e, ex) }
    }

    private fun handleFailure(app: Context, e: OutboxEntry, ex: Exception) {
        val code = (ex as? FirebaseFirestoreException)?.code
        if (code == null || code !in permanent) { // network, quota, sign-in: temporary, the order just keeps waiting
            release(e.id)
            return
        }
        // a refusal might only mean "this order already exists": check with the server before calling it refused
        FirebaseFirestore.getInstance().collection("orders").document(e.id).get(Source.SERVER)
            .addOnSuccessListener { s ->
                if (s.exists() && s.getString("createdBy") == e.ownerEmail) markSynced(app, e) else refuse(app, e, code.name)
                release(e.id)
            }
            .addOnFailureListener { ex2 ->
                if ((ex2 as? FirebaseFirestoreException)?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) refuse(app, e, code.name)
                release(e.id)
            }
    }

    // Manual "Try again" for a refused order
    fun retry(ctx: Context, id: String) {
        val app = ctx.applicationContext
        val e = all(app).firstOrNull { it.id == id } ?: return
        replace(app, e.copy(status = "pending"))
        version++
        submit(app, id)
    }

    // Waiting orders are re-checked on start, when the network returns, and every 5 minutes. Refused ones never retry by themselves.
    fun reconcile(ctx: Context, uid: String) {
        val app = ctx.applicationContext
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null || user.uid != uid) return
        for (e in forOwner(app, uid)) {
            if (e.status != "pending") continue
            if (synchronized(lock) { inFlight.contains(e.id) }) continue
            FirebaseFirestore.getInstance().collection("orders").document(e.id).get(Source.SERVER)
                .addOnSuccessListener { s ->
                    if (s.exists() && s.getString("createdBy") == e.ownerEmail) markSynced(app, e) else submit(app, e.id)
                }
                .addOnFailureListener { ex ->
                    // offline: leave it, Firestore keeps its own copy of the write. Only a refused read can still allow the create.
                    if ((ex as? FirebaseFirestoreException)?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) submit(app, e.id)
                }
        }
    }

    // Admin / family only, after a confirmation. The full details go into the log book first.
    fun discard(ctx: Context, e: OutboxEntry) {
        AuditLog.add("outbox.discard", e.id, summary(e) + " [" + e.ownerEmail + ", " + e.lastError + "]")
        synchronized(lock) {
            val list = readAll(ctx)
            list.removeAll { it.id == e.id }
            writeAll(ctx, list)
        }
        version++
    }
}
