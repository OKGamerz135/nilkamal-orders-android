package com.nilkamal.orders

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.Timestamp
import com.google.firebase.firestore.Query
import java.util.Calendar
import java.util.Date

data class Product(
    val id: String, val name: String, val nameHi: String, val nameMr: String,
    val category: String, val price: Long, val imageUrl: String, val active: Boolean
)

data class CartItem(
    val id: String, val name: String, val price: Long, val defPrice: Long, val qty: Int, val imageUrl: String
)

data class OrderItem(
    val productId: String, val name: String, val price: Long, val defPrice: Long, val qty: Long, val imageUrl: String
)

data class Order(
    val id: String, val customerName: String, val phone: String, val notes: String,
    val items: List<OrderItem>, val total: Long, val advance: Long, val balance: Long,
    val dueAt: Date?, val status: String, val refImage: String,
    val createdBy: String, val createdAt: Date?, val editedBy: String, val editedAt: Date?,
    val deletedBy: String, val deletedAt: Date?, val restoredBy: String, val restoredAt: Date?
)

data class LogEntry(
    val id: String, val by: String, val action: String, val label: String, val at: Date?,
    val changes: List<Triple<String, String, String>>
)

fun DocumentSnapshot.toProduct() = Product(
    id, getString("name") ?: "", getString("name_hi") ?: "", getString("name_mr") ?: "",
    getString("category") ?: "other", getLong("price") ?: 0L, getString("imageUrl") ?: "",
    getBoolean("active") != false
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toOrder(): Order {
    val raw = get("items") as? List<*> ?: emptyList<Any>()
    val items = raw.mapNotNull { m ->
        val mm = m as? Map<String, Any?> ?: return@mapNotNull null
        val price = (mm["price"] as? Number)?.toLong() ?: 0L
        OrderItem(
            productId = mm["productId"] as? String ?: "",
            name = mm["name"] as? String ?: "",
            price = price,
            defPrice = (mm["defPrice"] as? Number)?.toLong() ?: price,
            qty = (mm["qty"] as? Number)?.toLong() ?: 1L,
            imageUrl = mm["imageUrl"] as? String ?: ""
        )
    }
    return Order(
        id = id, customerName = getString("customerName") ?: "", phone = getString("phone") ?: "",
        notes = getString("notes") ?: "", items = items,
        total = getLong("total") ?: 0L, advance = getLong("advance") ?: 0L, balance = getLong("balance") ?: 0L,
        dueAt = getTimestamp("dueAt")?.toDate(), status = getString("status") ?: "new",
        refImage = getString("refImage") ?: "",
        createdBy = getString("createdBy") ?: "", createdAt = getTimestamp("createdAt")?.toDate(),
        editedBy = getString("editedBy") ?: "", editedAt = getTimestamp("editedAt")?.toDate(),
        deletedBy = getString("deletedBy") ?: "", deletedAt = getTimestamp("deletedAt")?.toDate(),
        restoredBy = getString("restoredBy") ?: "", restoredAt = getTimestamp("restoredAt")?.toDate()
    )
}

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toLog(): LogEntry {
    val raw = get("changes") as? List<*> ?: emptyList<Any>()
    val ch = raw.mapNotNull { m ->
        val mm = m as? Map<String, Any?> ?: return@mapNotNull null
        Triple(mm["f"] as? String ?: "", mm["from"] as? String ?: "", mm["to"] as? String ?: "")
    }
    return LogEntry(id, getString("by") ?: "", getString("action") ?: "", getString("label") ?: "", getTimestamp("at")?.toDate(), ch)
}

// The cart lives while the app is open
class CartState {
    val items = mutableStateListOf<CartItem>()
    fun count(): Int = items.sumOf { it.qty }
    fun total(): Long = items.sumOf { it.price * it.qty }
    fun qtyOf(id: String): Int = items.firstOrNull { it.id == id }?.qty ?: 0
    fun addMany(ps: List<Product>, lang: String) {
        ps.forEach { p ->
            val i = items.indexOfFirst { it.id == p.id }
            if (i >= 0) items[i] = items[i].copy(qty = items[i].qty + 1)
            else items.add(CartItem(p.id, pname(p, lang), p.price, p.price, 1, p.imageUrl))
        }
    }
    fun addCustom(name: String, price: Long) {
        items.add(CartItem("custom-" + System.currentTimeMillis(), name, price, price, 1, ""))
    }
    fun setQty(id: String, q: Int) {
        val i = items.indexOfFirst { it.id == id }
        if (i < 0) return
        if (q <= 0) items.removeAt(i) else items[i] = items[i].copy(qty = q)
    }
    fun setPrice(id: String, price: Long) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) items[i] = items[i].copy(price = price)
    }
    fun clear() = items.clear()
}

// Every action is written to the log book (admin reads it in stage 3)
object AuditLog {
    fun add(action: String, targetId: String, label: String, changes: List<Triple<String, String, String>> = emptyList()) {
        val by = FirebaseAuth.getInstance().currentUser?.email ?: return
        FirebaseFirestore.getInstance().collection("logs").add(
            hashMapOf<String, Any>(
                "at" to FieldValue.serverTimestamp(),
                "by" to by,
                "action" to action,
                "targetId" to targetId,
                "label" to label,
                "changes" to changes.map { mapOf("f" to it.first, "from" to it.second, "to" to it.third) }
            )
        )
    }
}

@Composable
fun rememberProducts(): List<Product> {
    var list by remember { mutableStateOf(emptyList<Product>()) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("products")
            .addSnapshotListener { s, _ -> if (s != null) list = s.documents.map { it.toProduct() } }
        onDispose { reg.remove() }
    }
    return list
}

@Composable
fun rememberActiveOrders(): List<Order> {
    var list by remember { mutableStateOf(emptyList<Order>()) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("orders")
            .whereIn("status", listOf("new", "progress", "ready"))
            .addSnapshotListener { s, _ ->
                if (s != null) list = s.documents.map { it.toOrder() }.sortedBy { it.dueAt?.time ?: 0L }
            }
        onDispose { reg.remove() }
    }
    return list
}

@Composable
fun rememberUnpaidOrders(): List<Order> {
    var list by remember { mutableStateOf(emptyList<Order>()) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("orders")
            .whereGreaterThan("balance", 0)
            .addSnapshotListener { s, _ ->
                if (s != null) list = s.documents.map { it.toOrder() }
                    .filter { it.status != "deleted" }.sortedBy { it.dueAt?.time ?: 0L }
            }
        onDispose { reg.remove() }
    }
    return list
}

@Composable
fun rememberTodayOrders(enabled: Boolean): List<Order> {
    var list by remember { mutableStateOf(emptyList<Order>()) }
    DisposableEffect(enabled) {
        if (!enabled) {
            onDispose { }
        } else {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val reg = FirebaseFirestore.getInstance().collection("orders")
                .whereGreaterThanOrEqualTo("createdAt", Timestamp(cal.time))
                .addSnapshotListener { snap, _ ->
                    if (snap != null) list = snap.documents.map { it.toOrder() }.filter { it.status != "deleted" }
                }
            onDispose { reg.remove() }
        }
    }
    return list
}

@Composable
fun rememberHistory(): List<Order> {
    var list by remember { mutableStateOf(emptyList<Order>()) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("orders")
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(300)
            .addSnapshotListener { snap, _ -> if (snap != null) list = snap.documents.map { it.toOrder() } }
        onDispose { reg.remove() }
    }
    return list
}

@Composable
fun rememberLogs(): List<LogEntry> {
    var list by remember { mutableStateOf(emptyList<LogEntry>()) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("logs")
            .orderBy("at", Query.Direction.DESCENDING).limit(300)
            .addSnapshotListener { snap, _ -> if (snap != null) list = snap.documents.map { it.toLog() } }
        onDispose { reg.remove() }
    }
    return list
}
