package com.nilkamal.orders

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.os.SystemClock
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

suspend fun <T> Task<T>.await2(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { c.resume(it) }
    addOnFailureListener { c.resumeWithException(it) }
}

// Employees may work offline for at most 4 hours, and only inside working hours.
// Time is measured with the phone's uptime clock (not the date), so changing the date does not help.
object Lease {
    const val LEASE_MS = 4 * 3600 * 1000L
    private const val IST_MS = 19_800_000L
    private const val DAY_MS = 86_400_000L

    data class Hours(val startMin: Int = 420, val endMin: Int = 1290, val lateUntil: Long = 0L)

    sealed class State {
        data class Ok(val leftMs: Long, val offlineForMs: Long) : State()
        data class Locked(val reason: String) : State()
    }

    private val http = OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).build()
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("lease", Context.MODE_PRIVATE)
    private fun bootCount(ctx: Context): Int = Settings.Global.getInt(ctx.contentResolver, Settings.Global.BOOT_COUNT, -1)

    fun clear(ctx: Context) { prefs(ctx).edit().clear().apply() }
    fun cachedRole(ctx: Context): String = prefs(ctx).getString("role", "worker") ?: "worker"
    fun setRole(ctx: Context, role: String) { prefs(ctx).edit().putString("role", role).apply() }

    // Google's server clock (from the HTTPS reply), not the phone's clock
    private fun fetchServerMs(): Pair<Long, Long>? {
        val req = Request.Builder().url("https://firestore.googleapis.com/").head().build()
        http.newCall(req).execute().use { r ->
            val d = r.headers.getDate("Date") ?: return null
            return Pair(d.time, SystemClock.elapsedRealtime())
        }
    }

    private fun save(ctx: Context, serverMs: Long, elapsedAt: Long, h: Hours, role: String) {
        prefs(ctx).edit()
            .putLong("serverMs", serverMs).putLong("renewElapsed", elapsedAt).putInt("boot", bootCount(ctx))
            .putInt("startMin", h.startMin).putInt("endMin", h.endMin).putLong("lateUntil", h.lateUntil)
            .putString("role", role).apply()
    }

    private fun msUntilClose(trustedMs: Long, h: Hours): Long {
        val lateLeft = maxOf(0L, h.lateUntil - trustedMs)
        val t = (trustedMs + IST_MS) % DAY_MS
        val start = h.startMin * 60_000L
        val end = h.endMin * 60_000L
        val winLeft = if (t in start until end) end - t else 0L
        return maxOf(lateLeft, winLeft)
    }

    fun state(ctx: Context): State {
        val p = prefs(ctx)
        if (!p.contains("renewElapsed")) return State.Locked("connect")
        val now = SystemClock.elapsedRealtime()
        val renewAt = p.getLong("renewElapsed", 0L)
        if (bootCount(ctx) != p.getInt("boot", -2) || now < renewAt) return State.Locked("reboot")
        val since = now - renewAt
        val left = LEASE_MS - since
        if (left <= 0) return State.Locked("expired")
        val trusted = p.getLong("serverMs", 0L) + since
        val h = Hours(p.getInt("startMin", 420), p.getInt("endMin", 1290), p.getLong("lateUntil", 0L))
        val closeIn = msUntilClose(trusted, h)
        if (closeIn <= 0) return State.Locked("closed")
        return State.Ok(minOf(left, closeIn), since)
    }

    // Best estimate of the real time, immune to date changes (falls back to the phone clock)
    fun trustedNowMs(ctx: Context): Long {
        val p = prefs(ctx)
        if (!p.contains("renewElapsed")) return System.currentTimeMillis()
        val now = SystemClock.elapsedRealtime()
        val renewAt = p.getLong("renewElapsed", 0L)
        if (bootCount(ctx) != p.getInt("boot", -2) || now < renewAt) return System.currentTimeMillis()
        return p.getLong("serverMs", 0L) + (now - renewAt)
    }

    // Talks to the server. Success renews the 4 hours.
    suspend fun renew(ctx: Context): Boolean {
        val user: FirebaseUser = FirebaseAuth.getInstance().currentUser ?: return false
        val clock = withContext(Dispatchers.IO) { runCatching { fetchServerMs() }.getOrNull() } ?: return false
        val db = FirebaseFirestore.getInstance()
        val ok = try {
            withTimeoutOrNull(15_000L) {
                val role = db.collection("users").document(user.uid).get(Source.SERVER).await2().getString("role") ?: "worker"
                val hs = db.collection("settings").document("hours").get(Source.SERVER).await2()
                val h = if (hs.exists()) Hours(
                    hs.getLong("startMin")?.toInt() ?: 420, hs.getLong("endMin")?.toInt() ?: 1290,
                    hs.getTimestamp("lateUntil")?.toDate()?.time ?: 0L
                ) else Hours()
                save(ctx, clock.first, clock.second, h, role)
                true
            } == true
        } catch (e: Exception) {
            false
        }
        if (ok) {
            // device list for the admin (best effort)
            db.collection("devices").document(Device.docId(ctx, user.uid)).set(Device.info(ctx, user), SetOptions.merge())
        }
        return ok
    }
}

private fun fmtLeft(ms: Long): String {
    val m = maxOf(0L, ms) / 60_000L
    return "${m / 60}h ${m % 60}m"
}

// Wraps the whole app for employees: locks it when the 4 hours / working hours run out.
@Composable
fun LeaseGate(role: String, roleLoaded: Boolean, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val exempt = role == "admin" || role == "family"
    val exemptNow by rememberUpdatedState(exempt)
    var tick by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val running = remember { booleanArrayOf(false) }

    fun renewNow() {
        scope.launch {
            if (running[0]) return@launch
            running[0] = true
            busy = true
            Lease.renew(ctx)
            running[0] = false
            busy = false
            tick++
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            renewNow()
            delay(10 * 60_000L)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000L)
            tick++
            if (!exemptNow && Lease.state(ctx) is Lease.State.Locked) renewNow()
        }
    }
    DisposableEffect(Unit) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { renewNow() }
        }
        cm.registerDefaultNetworkCallback(cb)
        onDispose { cm.unregisterNetworkCallback(cb) }
    }

    val st = remember(tick, exempt) { if (exempt) null else Lease.state(ctx) }
    val s = st
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        when {
            !roleLoaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("…") }
            s is Lease.State.Locked -> LockScreen(s.reason, busy) { renewNow() }
            else -> {
                if (s is Lease.State.Ok) {
                    val offline = s.offlineForMs > 15 * 60_000L
                    val warn = s.leftMs < 30 * 60_000L
                    if (offline || warn) OfflineBanner(offline, s.leftMs)
                }
                Box(Modifier.weight(1f)) { content() }
            }
        }
    }
}

@Composable
fun OfflineBanner(offline: Boolean, leftMs: Long) {
    val urgent = leftMs < 30 * 60_000L
    Text(
        (if (urgent) "⚠ " else "📴 ") + (if (offline) t("offlineLeft") else t("closingSoon")) + " " + fmtLeft(leftMs),
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.fillMaxWidth().background(if (urgent) Color(0xFFFDE68A) else Color(0xFFE0F2FE)).padding(10.dp)
    )
}

@Composable
fun LockScreen(reason: String, busy: Boolean, onRetry: () -> Unit) {
    val msg = when (reason) {
        "reboot" -> t("lockReboot")
        "expired" -> t("lockExpired")
        "closed" -> t("lockClosed")
        else -> t("lockConnect")
    }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔒", fontSize = 56.sp)
        Text(t("lockedTitle"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(msg, textAlign = TextAlign.Center, fontSize = 17.sp)
        Text(t("safeOrders"), textAlign = TextAlign.Center, color = Color(0xFF64748B))
        Button(onClick = onRetry, enabled = !busy) { Text(if (busy) "…" else t("retry")) }
    }
}
