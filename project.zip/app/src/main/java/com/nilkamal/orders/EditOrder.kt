package com.nilkamal.orders

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Admin / family only: change items, prices, name, phone, time, advance, notes. Every change goes in the log book.
@Composable
fun EditOrderDialog(o: Order, products: List<Product>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val items = remember { mutableStateListOf<OrderItem>().apply { addAll(o.items) } }
    var name by remember { mutableStateOf(o.customerName) }
    var phone by remember { mutableStateOf(o.phone) }
    var notes by remember { mutableStateOf(o.notes) }
    var due by remember { mutableStateOf(o.dueAt?.time) }
    var totalText by remember { mutableStateOf(o.total.toString()) }
    var advanceText by remember { mutableStateOf(o.advance.toString()) }
    var q by remember { mutableStateOf("") }
    var cn by remember { mutableStateOf("") }
    var cp by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val fmt = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)

    fun recalc() { totalText = items.sumOf { it.price * it.qty }.toString() }
    fun setQty(i: Int, qty: Long) {
        if (qty <= 0) items.removeAt(i) else items[i] = items[i].copy(qty = qty)
        recalc()
    }
    fun setPrice(i: Int, price: Long) {
        items[i] = items[i].copy(price = price)
        recalc()
    }
    fun addProduct(p: Product) {
        val i = items.indexOfFirst { it.productId == p.id }
        if (i >= 0) items[i] = items[i].copy(qty = items[i].qty + 1)
        else items.add(OrderItem(p.id, pname(p, lang), p.price, p.price, 1L, p.imageUrl))
        q = ""
        recalc()
    }

    fun save() {
        val total = totalText.toLongOrNull() ?: 0L
        val advance = advanceText.toLongOrNull() ?: 0L
        val dueMs = due
        if (name.isBlank() || phone.length != 10 || !phone.all { it.isDigit() } || dueMs == null ||
            items.isEmpty() || total <= 0 || advance < 0 || advance > total
        ) {
            msg = tr(lang, "err")
            return
        }
        val str = { l: List<OrderItem> -> l.joinToString(", ") { it.name + "×" + it.qty + "@" + it.price } }
        val ch = mutableListOf<Triple<String, String, String>>()
        fun cmp(f: String, a: String, b: String) { if (a != b) ch.add(Triple(f, a, b)) }
        cmp("customerName", o.customerName, name.trim())
        cmp("phone", o.phone, phone)
        cmp("notes", o.notes, notes)
        cmp("dueAt", o.dueAt?.let { fmt.format(it) } ?: "", fmt.format(Date(dueMs)))
        cmp("total", o.total.toString(), total.toString())
        cmp("advance", o.advance.toString(), advance.toString())
        cmp("items", str(o.items), str(items.toList()))
        if (ch.isEmpty()) {
            onClose()
            return
        }
        val email = FirebaseAuth.getInstance().currentUser?.email ?: ""
        val itemMaps = items.map {
            mapOf("productId" to it.productId, "name" to it.name, "price" to it.price, "defPrice" to it.defPrice, "qty" to it.qty, "imageUrl" to it.imageUrl)
        }
        val data = hashMapOf<String, Any>(
            "customerName" to name.trim(), "phone" to phone, "notes" to notes, "items" to itemMaps,
            "total" to total, "advance" to advance, "balance" to total - advance,
            "dueAt" to Timestamp(Date(dueMs)), "editedBy" to email, "editedAt" to FieldValue.serverTimestamp()
        )
        FirebaseFirestore.getInstance().collection("orders").document(o.id).update(data)
        AuditLog.add("order.edit", o.id, name.trim() + " · " + rs(total), ch)
        onClose()
    }

    val needle = q.trim().lowercase()
    val matches = if (needle.isEmpty()) emptyList() else products.filter { p ->
        p.active && listOf(p.name, p.nameHi, p.nameMr).any { it.lowercase().contains(needle) }
    }.take(6)

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(t("edit") + ": " + o.customerName, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                items.toList().forEachIndexed { i, it0 ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White)
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp)).padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Photo(it0.imageUrl, Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)), 20)
                            Text(it0.name, fontWeight = FontWeight.SemiBold)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { setQty(i, it0.qty - 1) }) { Text("−") }
                            Text(it0.qty.toString(), fontSize = 18.sp)
                            OutlinedButton(onClick = { setQty(i, it0.qty + 1) }) { Text("+") }
                            OutlinedTextField(
                                value = it0.price.toString(),
                                onValueChange = { v -> setPrice(i, v.filter { c -> c.isDigit() }.toLongOrNull() ?: 0L) },
                                label = { Text("₹") }, singleLine = true, keyboardOptions = numeric, modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
                Column(
                    Modifier.fillMaxWidth().border(1.dp, Color(0xFF94A3B8), RoundedCornerShape(12.dp)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text(t("addItem") + " — " + t("searchProduct")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    matches.forEach { p ->
                        OutlinedButton(onClick = { addProduct(p) }, modifier = Modifier.fillMaxWidth()) {
                            Text(pname(p, lang) + " · " + rs(p.price))
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = cn, onValueChange = { cn = it }, label = { Text(t("customItem")) }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = cp, onValueChange = { cp = it.filter { c -> c.isDigit() } }, label = { Text("₹") }, singleLine = true, keyboardOptions = numeric, modifier = Modifier.weight(0.6f))
                        OutlinedButton(onClick = {
                            val price = cp.toLongOrNull()
                            if (cn.isNotBlank() && price != null && price > 0) {
                                items.add(OrderItem("custom-" + System.currentTimeMillis(), cn.trim(), price, price, 1L, ""))
                                cn = ""
                                cp = ""
                                recalc()
                            }
                        }) { Text(t("addBtn")) }
                    }
                }
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(t("name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = phone, onValueChange = { phone = it.filter { c -> c.isDigit() }.take(10) },
                    label = { Text(t("phone")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(onClick = { pickDateTime(ctx) { due = it } }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    val d0 = due
                    Text(if (d0 == null) "📅 " + t("pickDateTime") else "📅 " + fmt.format(Date(d0)))
                }
                OutlinedTextField(value = totalText, onValueChange = { totalText = it.filter { c -> c.isDigit() } }, label = { Text(t("total") + " (₹)") }, singleLine = true, keyboardOptions = numeric, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = advanceText, onValueChange = { advanceText = it.filter { c -> c.isDigit() } }, label = { Text(t("advance") + " (₹)") }, singleLine = true, keyboardOptions = numeric, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(t("notes")) }, minLines = 3, modifier = Modifier.fillMaxWidth())
                if (msg.isNotEmpty()) Text(msg, color = Color(0xFFDC2626))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { save() }, modifier = Modifier.weight(1f).height(52.dp)) { Text(t("saveChanges")) }
                    OutlinedButton(onClick = onClose, modifier = Modifier.height(52.dp)) { Text(t("cancel")) }
                }
            }
        }
    }
}
