package com.nilkamal.orders

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun ShopScreen(cart: CartState, email: String, onSaved: () -> Unit) {
    val lang = LocalLang.current
    val products = rememberProducts()
    var cat by remember { mutableStateOf("all") }
    var q by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf<Set<String>?>(null) } // null = normal mode, set = Select mode
    var detailP by remember { mutableStateOf<Product?>(null) }
    var viewer by remember { mutableStateOf<String?>(null) }
    var showCart by remember { mutableStateOf(false) }

    val visible = products.filter { it.active }
    val needle = q.trim().lowercase()
    val shown = visible.filter { p ->
        (cat == "all" || p.category == cat) &&
            (needle.isEmpty() || listOf(p.name, p.nameHi, p.nameMr).any { it.lowercase().contains(needle) })
    }
    val s = sel

    Box(Modifier.fillMaxSize()) {
        if (showCart) {
            CartScreen(
                cart, products, email,
                onBack = { showCart = false },
                onSaved = { showCart = false; onSaved() }
            )
        } else {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        label = { Text(t("searchProduct")) }, modifier = Modifier.weight(1f)
                    )
                    if (s != null) Button(onClick = { sel = null }) { Text(t("cancel")) }
                    else OutlinedButton(onClick = { sel = emptySet() }) { Text(t("select")) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("all", "haar", "bouquet", "loose", "other").forEach { c ->
                        Chip(t(c), cat == c) { cat = c }
                    }
                }
                if (shown.isEmpty()) Text(t("empty"), modifier = Modifier.padding(16.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 88.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(shown, key = { it.id }) { p ->
                        val picked = s?.contains(p.id) == true
                        ProductCard(
                            p, lang, cart.qtyOf(p.id), s != null, picked,
                            onClick = {
                                if (s != null) {
                                    sel = if (picked) s - p.id else s + p.id
                                } else {
                                    detailP = p
                                }
                            },
                            onAdd = { cart.addMany(listOf(p), lang) },
                            onZoom = { viewer = p.imageUrl }
                        )
                    }
                }
            }
            if (s != null && s.isNotEmpty()) {
                Button(
                    onClick = { cart.addMany(visible.filter { it.id in s }, lang); sel = null },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(8.dp).height(56.dp)
                ) { Text(t("addToCart") + " (" + s.size + ")") }
            } else if (cart.items.isNotEmpty()) {
                Button(
                    onClick = { showCart = true },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(8.dp).height(56.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(t("cart") + " (" + cart.count() + ")")
                        Text(rs(cart.total()))
                    }
                }
            }
        }
    }

    val dProd = detailP
    if (dProd != null) {
        DetailDialog(
            DetailData(dProd.name, dProd.nameHi, dProd.nameMr, dProd.category, dProd.price, null, dProd.imageUrl),
            onClose = { detailP = null }
        ) {
            Button(onClick = { cart.addMany(listOf(dProd), lang) }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(t("addToCart")) }
            if (cart.qtyOf(dProd.id) > 0) Text(t("inCart") + ": " + cart.qtyOf(dProd.id))
        }
    }
    val v = viewer
    if (v != null) PhotoViewer(v) { viewer = null }
}

@Composable
fun ProductCard(
    p: Product, lang: String, qty: Int, selMode: Boolean, picked: Boolean,
    onClick: () -> Unit, onAdd: () -> Unit, onZoom: () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier.clip(shape).background(Color.White)
            .border(if (picked) 4.dp else 1.dp, if (picked) Rose else Color(0xFFE2E8F0), shape)
            .clickable(onClick = onClick)
    ) {
        Column {
            Photo(p.imageUrl, Modifier.fillMaxWidth().aspectRatio(1f), 40)
            Column(Modifier.padding(8.dp)) {
                Text(pname(p, lang), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Text(rs(p.price), color = Rose)
            }
        }
        if (qty > 0) {
            Text(
                qty.toString(), color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                    .background(Rose, CircleShape).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        Row(Modifier.align(Alignment.TopStart).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!selMode) {
                Pill("+", null, onAdd)
            } else {
                Pill(if (picked) "✓" else "", if (picked) Rose else null, onClick)
                if (p.imageUrl.isNotEmpty()) Pill("🔍", null, onZoom)
            }
        }
    }
}

@Composable
fun CartScreen(cart: CartState, products: List<Product>, email: String, onBack: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var advanceText by remember { mutableStateOf("") }
    var totalText by remember { mutableStateOf("") }
    var due by remember { mutableStateOf<Long?>(null) }
    var msg by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf<CartItem?>(null) }
    var cn by remember { mutableStateOf("") }
    var cp by remember { mutableStateOf("") }
    var refUri by remember { mutableStateOf<Uri?>(null) }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) refUri = u }

    val itemsTotal = cart.total()
    val total = totalText.toLongOrNull() ?: itemsTotal // follows the cart unless typed
    val advance = advanceText.toLongOrNull() ?: 0L
    val fmt = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)

    fun pickDue() {
        val c = Calendar.getInstance()
        DatePickerDialog(ctx, { _, y, m, d ->
            TimePickerDialog(ctx, { _, h, min ->
                val cal = Calendar.getInstance()
                cal.set(y, m, d, h, min, 0)
                cal.set(Calendar.MILLISECOND, 0)
                due = cal.timeInMillis
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    fun finish(dueMs: Long, refImage: String) {
        val ref = FirebaseFirestore.getInstance().collection("orders").document()
        val items = cart.items.map {
            mapOf("productId" to it.id, "name" to it.name, "name_hi" to it.nameHi, "name_mr" to it.nameMr, "price" to it.price, "defPrice" to it.defPrice, "qty" to it.qty, "imageUrl" to it.imageUrl)
        }
        val data = hashMapOf<String, Any>(
            "customerName" to name.trim(), "phone" to phone, "notes" to notes, "refImage" to refImage,
            "items" to items, "total" to total, "advance" to advance, "balance" to total - advance,
            "dueAt" to Timestamp(Date(dueMs)), "status" to "new",
            "createdAt" to FieldValue.serverTimestamp(), "createdBy" to email
        )
        ref.set(data) // not awaited: works offline and syncs later
        val bargains = cart.items.filter { it.price != it.defPrice }
            .map { Triple("price", it.name + ": " + it.defPrice, it.price.toString()) }
        AuditLog.add("order.create", ref.id, name.trim() + " · " + rs(total), bargains)
        cart.clear()
        Toast.makeText(ctx, tr(lang, "saved"), Toast.LENGTH_SHORT).show()
        onSaved()
    }

    fun save() {
        val dueMs = due
        if (name.isBlank() || phone.length != 10 || !phone.all { it.isDigit() } || dueMs == null ||
            cart.items.isEmpty() || total <= 0 || advance < 0 || advance > total
        ) {
            msg = tr(lang, "err")
            return
        }
        val u = refUri
        if (u == null) {
            finish(dueMs, "")
            return
        }
        saving = true
        msg = ""
        scope.launch {
            val url = withContext(Dispatchers.IO) { runCatching { Cloud.upload(ctx, u) }.getOrNull() }
            saving = false
            if (url == null) msg = tr(lang, "uploadFail") else finish(dueMs, url)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedButton(onClick = onBack) { Text("← " + t("back")) }
        if (cart.items.isEmpty()) Text(t("empty"))
        cart.items.toList().forEach { it0 ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White)
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp)).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Photo(it0.imageUrl, Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)).clickable { detail = it0 }, 28)
                    Text(cartName(it0, lang), fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { detail = it0 })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { cart.setQty(it0.id, it0.qty - 1) }) { Text("−") }
                    Text(it0.qty.toString(), fontSize = 18.sp)
                    OutlinedButton(onClick = { cart.setQty(it0.id, it0.qty + 1) }) { Text("+") }
                    OutlinedTextField(
                        value = it0.price.toString(),
                        onValueChange = { v -> cart.setPrice(it0.id, v.filter { c -> c.isDigit() }.toLongOrNull() ?: 0L) },
                        label = { Text("₹") }, singleLine = true, keyboardOptions = numeric, modifier = Modifier.weight(1f)
                    )
                }
            }
        }
        Column(
            Modifier.fillMaxWidth().border(1.dp, Color(0xFF94A3B8), RoundedCornerShape(12.dp)).padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(t("customItem"), fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = cn, onValueChange = { cn = it }, label = { Text(t("itemName")) }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = cp, onValueChange = { cp = it.filter { c -> c.isDigit() } }, label = { Text("₹") }, singleLine = true, keyboardOptions = numeric, modifier = Modifier.weight(0.6f))
                OutlinedButton(onClick = {
                    val price = cp.toLongOrNull()
                    if (cn.isNotBlank() && price != null && price > 0) { cart.addCustom(cn.trim(), price); cn = ""; cp = "" }
                }) { Text(t("addBtn")) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(t("itemsTotal"), fontSize = 18.sp)
            Text(rs(itemsTotal), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(t("name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = phone, onValueChange = { phone = it.filter { c -> c.isDigit() }.take(10) },
            label = { Text(t("phone")) }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(onClick = { pickDue() }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            val d0 = due
            Text(if (d0 == null) "📅 " + t("pickDateTime") else "📅 " + fmt.format(Date(d0)))
        }
        OutlinedTextField(
            value = if (totalText.isEmpty()) itemsTotal.toString() else totalText,
            onValueChange = { totalText = it.filter { c -> c.isDigit() } },
            label = { Text(t("total") + " (₹)") }, singleLine = true, keyboardOptions = numeric, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = advanceText, onValueChange = { advanceText = it.filter { c -> c.isDigit() } },
            label = { Text(t("advance") + " (₹)") }, singleLine = true, keyboardOptions = numeric, modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(t("balance"), fontSize = 20.sp)
            Text(rs(total - advance), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Rose)
        }
        OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(t("notes")) }, minLines = 3, modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("📷 " + t("refPhoto")) }
        val ru = refUri
        if (ru != null) {
            AsyncImage(model = ru, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(96.dp).clip(RoundedCornerShape(8.dp)))
        }
        if (msg.isNotEmpty()) Text(msg, color = Color(0xFFDC2626))
        Button(onClick = { save() }, enabled = !saving, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text(if (saving) t("uploading") else t("save"), fontSize = 18.sp)
        }
        OutlinedButton(onClick = { cart.clear() }, modifier = Modifier.fillMaxWidth()) { Text(t("clear")) }
    }

    val dt = detail
    if (dt != null) {
        val prod = products.firstOrNull { it.id == dt.id }
        DetailDialog(
            DetailData(
                prod?.name ?: dt.name, prod?.nameHi ?: "", prod?.nameMr ?: "", prod?.category ?: "",
                dt.price, dt.defPrice, dt.imageUrl.ifEmpty { prod?.imageUrl ?: "" }
            ),
            onClose = { detail = null }
        ) {
            Text(t("qty") + ": " + cart.qtyOf(dt.id), fontSize = 18.sp)
        }
    }
}
