package com.nilkamal.orders

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun isToday(d: Date): Boolean {
    val a = Calendar.getInstance()
    val b = Calendar.getInstance()
    b.time = d
    return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
}

@Composable
fun OrdersScreen(role: String) {
    val active = rememberActiveOrders()
    val unpaid = rememberUnpaidOrders()
    val products = rememberProducts()
    val pmap = products.associateBy { it.id }
    var filter by remember { mutableStateOf("active") }
    var open by remember { mutableStateOf<String?>(null) }
    var viewer by remember { mutableStateOf<String?>(null) }

    val list = when (filter) {
        "unpaid" -> unpaid
        "today" -> active.filter { val d = it.dueAt; d != null && isToday(d) }
        else -> active
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("active", "today", "unpaid").forEach { k -> Chip(t(k), filter == k) { filter = k } }
        }
        if (list.isEmpty()) Text(t("empty"), modifier = Modifier.padding(16.dp))
        LazyColumn(
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(list, key = { it.id }) { o ->
                OrderCard(o, pmap, open == o.id, onToggle = { open = if (open == o.id) null else o.id }, onPhoto = { viewer = it })
            }
        }
    }
    val v = viewer
    if (v != null) PhotoViewer(v) { viewer = null }
}

@Composable
fun OrderCard(o: Order, pmap: Map<String, Product>, expanded: Boolean, onToggle: () -> Unit, onPhoto: (String) -> Unit) {
    val ctx = LocalContext.current
    val fmt = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }
    val now = System.currentTimeMillis()
    val due = o.dueAt
    val late = due != null && o.status != "delivered" && due.time < now
    val soon = due != null && !late && o.status != "delivered" && due.time - now < 2 * 3600 * 1000L
    val borderColor = if (late) Color(0xFFEF4444) else if (soon) Color(0xFFF59E0B) else Color(0xFFE2E8F0)
    val bg = if (late) Color(0xFFFEF2F2) else if (soon) Color(0xFFFFFBEB) else Color.White
    val shape = RoundedCornerShape(12.dp)
    val label = o.customerName + " · " + rs(o.total)
    val db = FirebaseFirestore.getInstance()
    val nextStatus = mapOf("new" to "progress", "progress" to "ready", "ready" to "delivered")[o.status]

    Column(
        Modifier.fillMaxWidth().clip(shape).background(bg).border(1.dp, borderColor, shape)
            .clickable(onClick = onToggle).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(o.customerName, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            Text(t(o.status), modifier = Modifier.background(Color(0xFFE2E8F0), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 4.dp))
        }
        if (due != null) {
            val prefix = (if (late) t("overdue") + " · " else "") + (if (soon) t("dueSoon") + " · " else "")
            Text(prefix + fmt.format(due), fontWeight = if (late || soon) FontWeight.Bold else FontWeight.Normal,
                color = if (late) Color(0xFFB91C1C) else if (soon) Color(0xFFB45309) else Color.Unspecified)
        }
        Text(o.items.joinToString(", ") { it.name + " ×" + it.qty })
        if (expanded) {
            Column(
                Modifier.fillMaxWidth().background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp)).padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                o.items.forEach { i ->
                    val url = i.imageUrl.ifEmpty { pmap[i.productId]?.imageUrl ?: "" }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Photo(url, Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).clickable(enabled = url.isNotEmpty()) { onPhoto(url) }, 24)
                        Text(i.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("×" + i.qty, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (o.notes.isNotEmpty()) Text(o.notes, modifier = Modifier.fillMaxWidth().background(Color(0xFFFEF3C7), RoundedCornerShape(6.dp)).padding(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(t("total") + " " + rs(o.total))
            Text(t("advance") + " " + rs(o.advance))
            if (o.balance > 0) Text(t("balance") + " " + rs(o.balance), color = Rose, fontWeight = FontWeight.Bold)
            else Text(t("paid"), color = Color(0xFF15803D), fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+91" + o.phone))) },
                modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
            ) { Text("📞 " + t("call"), fontSize = 13.sp) }
            OutlinedButton(
                onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/91" + o.phone))) },
                modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
            ) { Text("💬 " + t("whatsapp"), fontSize = 13.sp) }
            if (o.balance > 0) {
                OutlinedButton(
                    onClick = {
                        db.collection("orders").document(o.id).update(mapOf("advance" to o.total, "balance" to 0L))
                        AuditLog.add("order.paid", o.id, label, listOf(Triple("advance", o.advance.toString(), o.total.toString())))
                    },
                    modifier = Modifier.weight(1.3f), contentPadding = PaddingValues(4.dp)
                ) { Text(t("markPaid"), fontSize = 13.sp) }
            }
        }
        if (nextStatus != null) {
            Button(
                onClick = {
                    db.collection("orders").document(o.id).update("status", nextStatus)
                    AuditLog.add("order.status", o.id, label, listOf(Triple("status", o.status, nextStatus)))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(t("moveTo") + ": " + t(nextStatus)) }
        }
    }
}
